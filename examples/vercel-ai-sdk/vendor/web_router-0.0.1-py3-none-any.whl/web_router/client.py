"""The router facade.

:class:`WebRouter` and :class:`AsyncWebRouter` hide which API is behind a call.
Point them at a provider name and call :meth:`WebRouter.search` or
:meth:`WebRouter.extract`; swapping backends is a one-word change at
construction, or a per-call ``provider=`` override.

A name does not imply both methods: most search backends do not extract, and
some extract backends do not search. Each method resolves the name against its
own registry, so asking one for a backend that only serves the other reports it
as unknown and lists the ones that method does serve.

:meth:`WebRouter.benchmark` is a reserved placeholder for a planned capability
and raises :class:`NotImplementedError` on both routers.
"""

from __future__ import annotations

from types import TracebackType
from typing import Any

from web_router.constants import DEFAULT_PROVIDER, MSG_NOT_IMPLEMENTED
from web_router.exceptions import ProviderNotFoundError
from web_router.providers.base import ExtractProvider, SearchProvider
from web_router.registry import (
    available_extract_providers,
    available_providers,
    create_extract_provider,
    create_provider,
)
from web_router.types import (
    ExtractFormat,
    ExtractRequest,
    ExtractResponse,
    Provider,
    SearchDepth,
    SearchRequest,
    SearchResponse,
    provider_name,
)


class _BaseRouter:
    """Provider resolution and caching shared by the sync and async routers."""

    def __init__(
        self,
        provider: str | Provider = DEFAULT_PROVIDER,
        *,
        provider_config: dict[str, dict[str, Any]] | None = None,
    ) -> None:
        """
        Args:
            provider: Name of the default provider, e.g. ``"nimble"`` or
                :attr:`Provider.NIMBLE`. Omit it to let ``auto`` choose.
            provider_config: Constructor kwargs per provider, keyed by provider
                name -- ``{"tavily": {"api_key": ..., "timeout": 30}}``. This is
                the only place credentials are passed explicitly; everything
                else comes from the environment.
        """
        name = provider_name(provider)
        # Either registry is enough to name a default: a router defaulted to a
        # search-only backend still extracts through `provider=`, and the
        # method that cannot serve the default says so when it is called.
        known = available_providers() + available_extract_providers()
        if name not in known:
            raise ProviderNotFoundError(name, known)

        self.default_provider = name
        # Normalized on the way in so a config key matches the lookup in
        # get_provider, whichever form -- enum, or odd casing -- it was given in.
        self._config: dict[str, dict[str, Any]] = {
            provider_name(key): dict(config) for key, config in (provider_config or {}).items()
        }
        self._instances: dict[str, SearchProvider] = {}
        # Keyed separately from the search instances: one name resolves to two
        # different classes, and a vendor serving both is two objects here.
        self._extract_instances: dict[str, ExtractProvider] = {}

    def get_provider(self, name: str | Provider | SearchProvider | None = None) -> SearchProvider:
        """Return the named search provider, constructing and caching it on first use.

        An already-constructed provider is returned untouched and never cached,
        so this router does not take ownership of something it did not build --
        see :meth:`WebRouter.close`.
        """
        if isinstance(name, SearchProvider):
            return name

        key = provider_name(name) if name is not None else self.default_provider
        if key not in self._instances:
            self._instances[key] = create_provider(key, **self._config.get(key, {}))
        return self._instances[key]

    def get_extract_provider(self, name: str | Provider | ExtractProvider | None = None) -> ExtractProvider:
        """Return the named extract provider, constructing and caching it on first use.

        The extract counterpart of :meth:`get_provider`, with the same
        ownership rule.
        """
        if isinstance(name, ExtractProvider):
            return name

        key = provider_name(name) if name is not None else self.default_provider
        if key not in self._extract_instances:
            self._extract_instances[key] = create_extract_provider(key, **self._config.get(key, {}))
        return self._extract_instances[key]

    @staticmethod
    def _build_request(
        query: str,
        *,
        max_results: int | None,
        search_depth: SearchDepth | None,
        include_domains: list[str] | None,
        exclude_domains: list[str] | None,
        country: str | None,
        locale: str | None,
        provider_options: dict[str, Any] | None,
    ) -> SearchRequest:
        return SearchRequest(
            query=query,
            max_results=max_results,
            search_depth=search_depth,
            include_domains=include_domains,
            exclude_domains=exclude_domains,
            country=country,
            locale=locale,
            provider_options=provider_options or {},
        )

    @staticmethod
    def _build_extract_request(
        urls: str | list[str],
        *,
        format: ExtractFormat | None,
        provider_options: dict[str, Any] | None,
    ) -> ExtractRequest:
        return ExtractRequest(
            # One URL is the common case and reads better unwrapped; the
            # request model carries a list either way, so providers that batch
            # and providers that do not see the same shape.
            urls=[urls] if isinstance(urls, str) else list(urls),
            format=format,
            provider_options=provider_options or {},
        )

    def _all_instances(self) -> list[SearchProvider | ExtractProvider]:
        return [*self._instances.values(), *self._extract_instances.values()]

    def __repr__(self) -> str:
        return f"<{type(self).__name__} default_provider={self.default_provider!r}>"


class WebRouter(_BaseRouter):
    """Synchronous router.

    Example:
        >>> router = WebRouter("nimble")
        >>> response = router.search("who won the 2022 world cup", max_results=5)
        >>> response.urls
        >>> router.extract(response.urls[:3], format="markdown")
    """

    def search(
        self,
        query: str,
        *,
        provider: str | Provider | SearchProvider | None = None,
        max_results: int | None = None,
        search_depth: SearchDepth | None = None,
        include_domains: list[str] | None = None,
        exclude_domains: list[str] | None = None,
        country: str | None = None,
        locale: str | None = None,
        provider_options: dict[str, Any] | None = None,
    ) -> SearchResponse:
        """Search the web through ``provider`` (or the router's default)."""
        request = self._build_request(
            query,
            max_results=max_results,
            search_depth=search_depth,
            include_domains=include_domains,
            exclude_domains=exclude_domains,
            country=country,
            locale=locale,
            provider_options=provider_options,
        )
        return self.get_provider(provider).search(request)

    def benchmark(
        self,
        query: str,
        *,
        providers: list[str | Provider] | None = None,
        **kwargs: Any,
    ) -> Any:
        """Run the same query across several providers and compare them.

        Placeholder: raises :class:`NotImplementedError`. The signature is
        provisional -- ``providers`` defaults to every configured backend, and
        the return type lands once the comparison shape is settled.
        """
        # TODO: implement -- fan out across providers and return a comparison.
        raise NotImplementedError(MSG_NOT_IMPLEMENTED.format(method="WebRouter.benchmark()"))

    def extract(
        self,
        urls: str | list[str],
        *,
        provider: str | Provider | ExtractProvider | None = None,
        format: ExtractFormat | None = None,
        provider_options: dict[str, Any] | None = None,
    ) -> ExtractResponse:
        """Fetch the contents of one or more URLs through ``provider`` (or the router's default).

        Several URLs can partly succeed: what came back is in
        :attr:`~web_router.ExtractResponse.documents` and everything that did
        not is in :attr:`~web_router.ExtractResponse.failures`. A call where
        nothing came back raises instead.
        """
        request = self._build_extract_request(urls, format=format, provider_options=provider_options)
        return self.get_extract_provider(provider).extract(request)

    def close(self) -> None:
        """Close every provider this router built.

        A provider passed in already constructed is the caller's to close; this
        router never cached it and must not shut its client down.
        """
        for instance in self._all_instances():
            instance.close()

    def __enter__(self) -> WebRouter:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()


class AsyncWebRouter(_BaseRouter):
    """Asynchronous router.

    Example:
        >>> async with AsyncWebRouter("nimble") as router:
        ...     response = await router.search("latest nvidia earnings")
    """

    async def search(
        self,
        query: str,
        *,
        provider: str | Provider | SearchProvider | None = None,
        max_results: int | None = None,
        search_depth: SearchDepth | None = None,
        include_domains: list[str] | None = None,
        exclude_domains: list[str] | None = None,
        country: str | None = None,
        locale: str | None = None,
        provider_options: dict[str, Any] | None = None,
    ) -> SearchResponse:
        """Search the web through ``provider`` (or the router's default)."""
        request = self._build_request(
            query,
            max_results=max_results,
            search_depth=search_depth,
            include_domains=include_domains,
            exclude_domains=exclude_domains,
            country=country,
            locale=locale,
            provider_options=provider_options,
        )
        return await self.get_provider(provider).asearch(request)

    async def benchmark(
        self,
        query: str,
        *,
        providers: list[str | Provider] | None = None,
        **kwargs: Any,
    ) -> Any:
        """Run the same query across several providers and compare them.

        Placeholder: raises :class:`NotImplementedError`. The signature is
        provisional -- ``providers`` defaults to every configured backend, and
        the return type lands once the comparison shape is settled.
        """
        # TODO: implement -- fan out across providers and return a comparison.
        raise NotImplementedError(MSG_NOT_IMPLEMENTED.format(method="AsyncWebRouter.benchmark()"))

    async def extract(
        self,
        urls: str | list[str],
        *,
        provider: str | Provider | ExtractProvider | None = None,
        format: ExtractFormat | None = None,
        provider_options: dict[str, Any] | None = None,
    ) -> ExtractResponse:
        """Fetch the contents of one or more URLs through ``provider`` (or the router's default).

        Backends that take one URL per call are fanned out concurrently. As on
        the sync router, a partly successful call returns its failures and one
        where nothing came back raises.
        """
        request = self._build_extract_request(urls, format=format, provider_options=provider_options)
        return await self.get_extract_provider(provider).aextract(request)

    async def aclose(self) -> None:
        """Close every provider this router built.

        A provider passed in already constructed is the caller's to close; this
        router never cached it and must not shut its client down.
        """
        for instance in self._all_instances():
            await instance.aclose()

    async def __aenter__(self) -> AsyncWebRouter:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.aclose()
