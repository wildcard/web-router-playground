"""You.com provider over its MCP endpoint, which needs no credential.

This is a different service from :mod:`web_router.providers.you`, not a mode of
it: the REST search API at ``ydc-index.io`` is paid and returns 402 without a
key, while ``api.you.com/mcp?profile=free`` is open. The transport differs too
-- JSON-RPC wrapped in server-sent events rather than a plain JSON body.

What it returns, once unwrapped, is the same payload shape the REST API sends,
so this subclasses :class:`YouProvider` for normalization and overrides only
the transport. A change to You.com's result shape then lands in both at once.

Install with ``pip install 'web-router[search]'`` -- it needs ``httpx`` and
nothing else.
"""

from __future__ import annotations

import json
from typing import Any, ClassVar

import httpx

from web_router.constants import (
    HTTP_ERROR_BODY_LIMIT,
    MSG_HTTP_ERROR,
    MSG_MCP_ERROR,
    MSG_MCP_NO_RESULT,
    PROVIDER_YOU_MCP,
    YOU_MCP_ACCEPT,
    YOU_MCP_BASE_URL,
    YOU_MCP_EXTRACTION_BY_DEPTH,
    YOU_MCP_PROTOCOL_VERSION,
    YOU_MCP_SEARCH_PATH,
    YOU_MCP_SEARCH_TOOL,
    YOU_MCP_SSE_DATA_PREFIX,
    YOU_PARAM_NAMES,
)
from web_router.exceptions import ProviderError
from web_router.providers._utils import build_payload
from web_router.providers.you import YouProvider
from web_router.types import SearchRequest


class YouMcpProvider(YouProvider):
    """Routes searches to You.com's anonymous MCP endpoint."""

    name: ClassVar[str] = PROVIDER_YOU_MCP

    base_url: ClassVar[str] = YOU_MCP_BASE_URL
    search_path: ClassVar[str] = YOU_MCP_SEARCH_PATH
    env_api_key: ClassVar[str | None] = None

    def __init__(self, **kwargs: Any) -> None:
        headers = {"Accept": YOU_MCP_ACCEPT, **(kwargs.pop("headers", None) or {})}
        super().__init__(headers=headers, **kwargs)

    def _build_payload(self, request: SearchRequest) -> dict[str, Any]:
        """Same arguments as the REST provider, except how extraction is spelled."""
        extraction = YOU_MCP_EXTRACTION_BY_DEPTH.get(request.search_depth) if request.search_depth else None
        return build_payload(request, YOU_PARAM_NAMES, query=request.query, extraction=extraction)

    def _call_kwargs(self, request: SearchRequest) -> dict[str, Any]:
        """Wrap the search arguments in a JSON-RPC ``tools/call``.

        The arguments themselves still come from the inherited
        ``_build_payload``, so the mapping tables stay the single description
        of what web-router sends You.com.
        """
        return {
            "json": {
                "jsonrpc": YOU_MCP_PROTOCOL_VERSION,
                "id": 1,
                "method": "tools/call",
                "params": {"name": YOU_MCP_SEARCH_TOOL, "arguments": self._build_payload(request)},
            }
        }

    def _payload(self, response: httpx.Response) -> dict[str, Any]:
        """Unwrap the search payload from the JSON-RPC envelope inside the event stream."""
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            detail = MSG_HTTP_ERROR.format(
                status=exc.response.status_code, body=exc.response.text[:HTTP_ERROR_BODY_LIMIT]
            )
            raise ProviderError(self.name, detail, original=exc) from exc

        for message in self._messages(response.text):
            if error := message.get("error"):
                raise ProviderError(self.name, MSG_MCP_ERROR.format(error=error))
            # Progress notifications share the stream with the answer; only the
            # reply to our call carries "result".
            if "result" in message:
                return self._unwrap(message["result"])

        raise ProviderError(self.name, MSG_MCP_NO_RESULT)

    @staticmethod
    def _messages(body: str) -> list[dict[str, Any]]:
        """Decode the JSON-RPC messages carried by an SSE body, skipping undecodable frames."""
        messages = []
        for line in body.splitlines():
            if line.startswith(YOU_MCP_SSE_DATA_PREFIX):
                try:
                    messages.append(json.loads(line[len(YOU_MCP_SSE_DATA_PREFIX) :]))
                except json.JSONDecodeError:
                    continue
        return messages

    def _unwrap(self, result: dict[str, Any]) -> dict[str, Any]:
        """Pull the search payload out of the tool result's text content."""
        if result.get("isError"):
            raise ProviderError(self.name, MSG_MCP_ERROR.format(error=result))

        text = "".join(block.get("text", "") for block in result.get("content") or [])
        if not text:
            raise ProviderError(self.name, MSG_MCP_NO_RESULT)

        payload: dict[str, Any] = json.loads(text)
        return payload
