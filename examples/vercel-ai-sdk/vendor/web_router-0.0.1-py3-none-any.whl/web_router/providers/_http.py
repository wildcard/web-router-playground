"""Base classes for providers that talk to a REST API directly.

Several of these APIs publish no Python SDK, and for the slim usage web-router
makes of them an SDK dependency would buy little. :class:`_HttpProvider` owns
everything those providers share -- client construction, auth headers, HTTP
error mapping, cleanup -- and the two classes built on it leave a provider with
just two methods: build the request, read the response.

To add a search backend::

    class AcmeProvider(HttpSearchProvider):
        name = "acme"
        supported_parameters = frozenset({"max_results"})
        base_url = "https://api.acme.com"
        search_path = "/v1/search"
        env_api_key = "ACME_API_KEY"
        api_key_header = "X-API-Key"

        def _build_payload(self, request): ...
        def _to_response(self, request, payload): ...

An extract backend is the same shape, against :class:`HttpExtractProvider`,
with ``extract_path`` in place of ``search_path`` and a list of URLs passed
alongside the request.
"""

from __future__ import annotations

import abc
from typing import Any, ClassVar, Literal

import httpx

from web_router.constants import (
    DEFAULT_HTTP_TIMEOUT,
    FOLLOW_REDIRECTS,
    HTTP_ERROR_BODY_LIMIT,
    MSG_HTTP_ERROR,
    MSG_REDIRECTS_WITH_CREDENTIAL,
)
from web_router.exceptions import ConfigurationError, ProviderError
from web_router.providers._utils import compact, resolve_api_key
from web_router.providers.base import ExtractProvider, SearchProvider, _BaseProvider
from web_router.types import ExtractRequest, ExtractResponse, SearchRequest, SearchResponse


class _HttpProvider(_BaseProvider):
    """A provider backed by a plain HTTP endpoint."""

    base_url: ClassVar[str]

    env_api_key: ClassVar[str | None] = None
    """Variable holding this provider's credential, or ``None`` if it needs none.

    A keyless endpoint sends no auth header and never raises for a missing key.
    """

    api_key_header: ClassVar[str] = "Authorization"
    """Header carrying the credential."""

    api_key_prefix: ClassVar[str] = ""
    """Prepended to the key, e.g. ``"Bearer "``."""

    http_method: ClassVar[Literal["GET", "POST"]] = "POST"
    """``POST`` sends the payload as JSON; ``GET`` sends it as query parameters."""

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = DEFAULT_HTTP_TIMEOUT,
        **kwargs: Any,
    ) -> None:
        """
        Args:
            api_key: Falls back to this provider's ``env_api_key`` variable.
                Ignored by a keyless provider, which declares no variable.
            base_url: Override the API host.
            timeout: Request timeout in seconds, applied to both clients.
            **kwargs: Forwarded to the underlying ``httpx`` clients.

        Raises:
            ConfigurationError: if ``follow_redirects=True`` is passed to a
                provider that sends a credential -- see
                :data:`~web_router.constants.FOLLOW_REDIRECTS`.
        """
        key = self._resolve_key(api_key)
        url = base_url or self.base_url
        super().__init__(api_key=key, base_url=url, timeout=timeout, **kwargs)

        # Merge rather than replace: a caller passing headers= must not silently
        # drop the auth header and get an unexplained 401.
        headers = {"Accept": "application/json"}
        if key is not None:
            headers.update(self._auth_headers(key))
        headers.update(kwargs.pop("headers", None) or {})

        follow_redirects = bool(kwargs.pop("follow_redirects", FOLLOW_REDIRECTS))
        if follow_redirects and key is not None:
            raise ConfigurationError(MSG_REDIRECTS_WITH_CREDENTIAL.format(provider=self.name))

        self._client_kwargs: dict[str, Any] = {
            "base_url": url,
            "timeout": timeout,
            "headers": headers,
            # Pinned rather than left to httpx's default, so the credential
            # cannot travel to a host this provider never meant to call.
            "follow_redirects": follow_redirects,
            **compact(kwargs),
        }
        # Built on first use, and only the one actually used: constructing both
        # eagerly left a sync caller holding an open async connection pool that
        # close() had no way to shut down.
        self._sync: httpx.Client | None = None
        self._async: httpx.AsyncClient | None = None

    def _resolve_key(self, api_key: str | None) -> str | None:
        if not self.env_api_key:
            return None
        return resolve_api_key(api_key, env_var=self.env_api_key, provider=self.name)

    def _auth_headers(self, key: str) -> dict[str, str]:
        """Headers that carry the credential. Overridden by providers that do not use one header.

        Whatever this returns, a provider whose key is set is one the redirect
        pin above refuses to relax, so an unusual auth scheme cannot opt out of
        it by building its own header.
        """
        return {self.api_key_header: f"{self.api_key_prefix}{key}"}

    @property
    def _client(self) -> httpx.Client:
        if self._sync is None:
            self._sync = httpx.Client(**self._client_kwargs)
        return self._sync

    @property
    def _async_client(self) -> httpx.AsyncClient:
        if self._async is None:
            self._async = httpx.AsyncClient(**self._client_kwargs)
        return self._async

    def _payload(self, response: httpx.Response) -> dict[str, Any]:
        """Return the decoded body, turning an HTTP error into a message worth reading.

        Everything else -- timeouts, connection failures, bad JSON -- is wrapped
        by the public ``search``/``extract``.
        """
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            detail = MSG_HTTP_ERROR.format(
                status=exc.response.status_code,
                body=exc.response.text[:HTTP_ERROR_BODY_LIMIT],
            )
            raise ProviderError(self.name, detail, original=exc) from exc

        body: dict[str, Any] = response.json()
        return body

    def close(self) -> None:
        # Via the attribute, not the property: closing must never be the thing
        # that constructs a client.
        if self._sync is not None:
            self._sync.close()

    async def aclose(self) -> None:
        if self._async is not None:
            await self._async.aclose()
        # An async caller may still have built a sync client -- through the
        # sync path, or a library that probed it -- and aclose() is the only
        # shutdown they will call.
        self.close()


class HttpSearchProvider(_HttpProvider, SearchProvider):
    """A search backend over a plain HTTP endpoint."""

    search_path: ClassVar[str]

    # -- What subclasses implement -------------------------------------------

    @abc.abstractmethod
    def _build_payload(self, request: SearchRequest) -> dict[str, Any]:
        """Translate a normalized request into this API's request body or query."""

    @abc.abstractmethod
    def _to_response(self, request: SearchRequest, payload: dict[str, Any]) -> SearchResponse:
        """Translate this API's response into a normalized one."""

    # -- The HTTP plumbing ---------------------------------------------------

    def _search(self, request: SearchRequest) -> SearchResponse:
        response = self._client.request(self.http_method, self.search_path, **self._call_kwargs(request))
        return self._to_response(request, self._payload(response))

    async def _asearch(self, request: SearchRequest) -> SearchResponse:
        response = await self._async_client.request(self.http_method, self.search_path, **self._call_kwargs(request))
        return self._to_response(request, self._payload(response))

    def _call_kwargs(self, request: SearchRequest) -> dict[str, Any]:
        payload = self._build_payload(request)
        return {"json": payload} if self.http_method == "POST" else {"params": payload}


class HttpExtractProvider(_HttpProvider, ExtractProvider):
    """An extract backend over a plain HTTP endpoint."""

    extract_path: ClassVar[str]

    # -- What subclasses implement -------------------------------------------

    @abc.abstractmethod
    def _build_payload(self, request: ExtractRequest, urls: list[str]) -> dict[str, Any]:
        """Translate a normalized request into this API's request body or query.

        ``urls`` is one call's worth -- every URL for an API that batches them,
        a single-item list for one that does not.
        """

    @abc.abstractmethod
    def _to_response(self, request: ExtractRequest, urls: list[str], payload: dict[str, Any]) -> ExtractResponse:
        """Translate one call's response into a normalized one.

        ``urls`` is this call's own batch, not the whole request: a backend that
        does not echo the URL back must label its document from here, or every
        call after the first would be labelled with the first URL asked for.
        """

    # -- The HTTP plumbing ---------------------------------------------------

    def _extract(self, request: ExtractRequest, urls: list[str]) -> ExtractResponse:
        response = self._client.request(self.http_method, self.extract_path, **self._call_kwargs(request, urls))
        return self._to_response(request, urls, self._payload(response))

    async def _aextract(self, request: ExtractRequest, urls: list[str]) -> ExtractResponse:
        response = await self._async_client.request(
            self.http_method, self.extract_path, **self._call_kwargs(request, urls)
        )
        return self._to_response(request, urls, self._payload(response))

    def _call_kwargs(self, request: ExtractRequest, urls: list[str]) -> dict[str, Any]:
        payload = self._build_payload(request, urls)
        return {"json": payload} if self.http_method == "POST" else {"params": payload}
