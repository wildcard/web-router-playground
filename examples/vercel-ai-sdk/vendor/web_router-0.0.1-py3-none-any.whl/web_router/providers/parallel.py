"""Parallel provider, over the Search API.

Talks to the REST endpoint directly rather than through ``parallel-web``:
web-router uses two fields of this API, which an SDK dependency would not
simplify. Install with ``pip install 'web-router[search]'``. Reads
``PARALLEL_API_KEY`` unless a key is passed explicitly.

Slim by design: only ``max_results`` is mapped. Everything else is reachable
through ``provider_options``; mapping one properly is a welcome PR -- see
CONTRIBUTING.md.
"""

from __future__ import annotations

from typing import Any, ClassVar

from web_router.constants import (
    ENV_PARALLEL_API_KEY,
    PARALLEL_API_KEY_HEADER,
    PARALLEL_BASE_URL,
    PARALLEL_PARAM_NAMES,
    PARALLEL_SEARCH_PATH,
    PROVIDER_PARALLEL,
)
from web_router.providers._http import HttpSearchProvider
from web_router.providers._utils import as_snippet, build_payload
from web_router.types import SearchRequest, SearchResponse, SearchResult

_MAPPED_RESULT_FIELDS = frozenset({"url", "title", "excerpts", "publish_date"})


class ParallelProvider(HttpSearchProvider):
    """Routes searches to the Parallel Search API."""

    name: ClassVar[str] = PROVIDER_PARALLEL
    supported_parameters: ClassVar[frozenset[str]] = frozenset(PARALLEL_PARAM_NAMES)

    base_url: ClassVar[str] = PARALLEL_BASE_URL
    search_path: ClassVar[str] = PARALLEL_SEARCH_PATH
    env_api_key: ClassVar[str] = ENV_PARALLEL_API_KEY
    api_key_header: ClassVar[str] = PARALLEL_API_KEY_HEADER

    def _build_payload(self, request: SearchRequest) -> dict[str, Any]:
        # Parallel is built around an objective plus the queries to run for it.
        # With a single normalized query, both are that query.
        return build_payload(
            request,
            PARALLEL_PARAM_NAMES,
            objective=request.query,
            search_queries=[request.query],
        )

    def _to_response(self, request: SearchRequest, payload: dict[str, Any]) -> SearchResponse:
        return SearchResponse(
            provider=self.name,
            query=request.query,
            results=[self._to_result(hit) for hit in payload.get("results") or []],
            request_id=payload.get("search_id"),
            raw=payload,
        )

    @staticmethod
    def _to_result(hit: dict[str, Any]) -> SearchResult:
        # Parallel returns ranked page excerpts rather than a snippet, and they
        # run to thousands of characters -- so the body is all of them, and the
        # description is the head of the first.
        excerpts = [excerpt for excerpt in hit.get("excerpts") or [] if excerpt]
        return SearchResult(
            url=hit.get("url", ""),
            title=hit.get("title") or "",
            description=as_snippet(excerpts[0]) if excerpts else "",
            content="\n\n".join(excerpts),
            published_date=hit.get("publish_date"),
            extra={k: v for k, v in hit.items() if k not in _MAPPED_RESULT_FIELDS},
        )
