"""Perplexity provider, over the Search API.

This is the ``/search`` endpoint, which returns ranked web results -- not the
Sonar chat completions API. Install with ``pip install 'web-router[search]'``.
Reads ``PERPLEXITY_API_KEY`` unless a key is passed explicitly.

Slim by design: only ``max_results`` is mapped. Everything else is reachable
through ``provider_options``; mapping one properly is a welcome PR -- see
CONTRIBUTING.md.
"""

from __future__ import annotations

from typing import Any, ClassVar

from web_router.constants import (
    ENV_PERPLEXITY_API_KEY,
    PERPLEXITY_API_KEY_HEADER,
    PERPLEXITY_API_KEY_PREFIX,
    PERPLEXITY_BASE_URL,
    PERPLEXITY_PARAM_NAMES,
    PERPLEXITY_SEARCH_PATH,
    PROVIDER_PERPLEXITY,
)
from web_router.providers._http import HttpSearchProvider
from web_router.providers._utils import build_payload
from web_router.types import SearchRequest, SearchResponse, SearchResult

_MAPPED_RESULT_FIELDS = frozenset({"url", "title", "snippet", "date"})


class PerplexityProvider(HttpSearchProvider):
    """Routes searches to the Perplexity Search API."""

    name: ClassVar[str] = PROVIDER_PERPLEXITY
    supported_parameters: ClassVar[frozenset[str]] = frozenset(PERPLEXITY_PARAM_NAMES)

    base_url: ClassVar[str] = PERPLEXITY_BASE_URL
    search_path: ClassVar[str] = PERPLEXITY_SEARCH_PATH
    env_api_key: ClassVar[str] = ENV_PERPLEXITY_API_KEY
    api_key_header: ClassVar[str] = PERPLEXITY_API_KEY_HEADER
    api_key_prefix: ClassVar[str] = PERPLEXITY_API_KEY_PREFIX

    def _build_payload(self, request: SearchRequest) -> dict[str, Any]:
        return build_payload(request, PERPLEXITY_PARAM_NAMES, query=request.query)

    def _to_response(self, request: SearchRequest, payload: dict[str, Any]) -> SearchResponse:
        return SearchResponse(
            provider=self.name,
            query=request.query,
            results=[self._to_result(hit) for hit in payload.get("results") or []],
            request_id=payload.get("id"),
            raw=payload,
        )

    @staticmethod
    def _to_result(hit: dict[str, Any]) -> SearchResult:
        snippet = hit.get("snippet") or ""
        return SearchResult(
            url=hit.get("url", ""),
            title=hit.get("title") or "",
            description=snippet,
            content=snippet,
            published_date=hit.get("date"),
            extra={k: v for k, v in hit.items() if k not in _MAPPED_RESULT_FIELDS},
        )
