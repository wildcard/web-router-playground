"""The contract every provider implements.

A provider does one job: translate between web-router's normalized types and
whatever its API speaks. The invariants that make the router trustworthy --
rejecting unmapped options, wrapping backend failures -- are enforced in the
public :meth:`SearchProvider.search` and :meth:`ExtractProvider.extract`, so a
new provider gets them by construction and cannot forget them.

There is one base class per method. A vendor that serves both writes two
classes, which is what lets a backend appear under ``extract`` and not under
``search``, or the other way round.
"""

from __future__ import annotations

import abc
import asyncio
from typing import Any, ClassVar

from web_router.constants import (
    MAX_CONCURRENT_EXTRACTS,
    MSG_EXTRACT_FAILED,
    MSG_EXTRACT_NO_DOCUMENT,
    MSG_EXTRACT_NOTHING_RETURNED,
    MSG_SEARCH_FAILED,
)
from web_router.exceptions import ProviderError, UnsupportedFormatError, UnsupportedParameterError, WebRouterError
from web_router.types import (
    ExtractedDocument,
    ExtractFailure,
    ExtractFormat,
    ExtractRequest,
    ExtractResponse,
    NormalizedRequest,
    SearchRequest,
    SearchResponse,
)


class _BaseProvider(abc.ABC):
    """What a provider is, whichever method it serves."""

    name: ClassVar[str]

    supported_parameters: ClassVar[frozenset[str]] = frozenset()
    """Normalized options this backend maps.

    Anything outside this set is rejected rather than dropped, so a call never
    silently runs without something the caller asked for. See
    :meth:`~web_router.types.NormalizedRequest.normalized_parameters` for
    everything on offer.
    """

    def __init__(self, *, api_key: str | None = None, **kwargs: Any) -> None:
        self.api_key = api_key
        self.options = kwargs

    def _reject_unmapped(self, request: NormalizedRequest) -> None:
        unmapped = request.specified_parameters() - self.supported_parameters
        if unmapped:
            raise UnsupportedParameterError(self.name, unmapped)

    def close(self) -> None:  # noqa: B027
        """Release sync resources."""

    async def aclose(self) -> None:  # noqa: B027
        """Release async resources."""

    def __repr__(self) -> str:
        # Deliberately omits api_key and options so a stray log never leaks a credential.
        return f"<{type(self).__name__} name={self.name!r}>"


class SearchProvider(_BaseProvider):
    """Base class for a search backend.

    To add one, set :attr:`name` and :attr:`supported_parameters`, then
    implement :meth:`_search` and :meth:`_asearch`. Override ``close``/``aclose``
    if the provider holds a client. See CONTRIBUTING.md for the full checklist.
    """

    # -- What subclasses implement -------------------------------------------

    @abc.abstractmethod
    def _search(self, request: SearchRequest) -> SearchResponse:
        """Run the search. The request is already validated; errors are wrapped for you."""

    @abc.abstractmethod
    async def _asearch(self, request: SearchRequest) -> SearchResponse:
        """Async counterpart of :meth:`_search`."""

    # -- What callers use ----------------------------------------------------

    def search(self, request: SearchRequest) -> SearchResponse:
        """Validate the request, run it, and wrap any backend failure."""
        self.validate(request)
        try:
            return self._search(request)
        except WebRouterError:
            raise
        except Exception as exc:
            raise ProviderError(self.name, MSG_SEARCH_FAILED.format(error=exc), original=exc) from exc

    async def asearch(self, request: SearchRequest) -> SearchResponse:
        """Async counterpart of :meth:`search`."""
        self.validate(request)
        try:
            return await self._asearch(request)
        except WebRouterError:
            raise
        except Exception as exc:
            raise ProviderError(self.name, MSG_SEARCH_FAILED.format(error=exc), original=exc) from exc

    def validate(self, request: SearchRequest) -> None:
        """Raise :class:`UnsupportedParameterError` for any option this backend does not map."""
        self._reject_unmapped(request)


class ExtractProvider(_BaseProvider):
    """Base class for a URL-contents backend.

    To add one, set :attr:`name`, :attr:`supported_parameters`,
    :attr:`supported_formats` and :attr:`default_format`, then implement
    :meth:`_extract` and :meth:`_aextract`. See CONTRIBUTING.md for the full
    checklist.

    Fanning several URLs out across calls is handled here, so a backend that
    takes one URL per request behaves like one that takes them all at once: the
    documents that came back are returned, and the URLs that did not are
    reported as failures rather than aborting the ones that worked.
    """

    supported_formats: ClassVar[frozenset[ExtractFormat]] = frozenset()
    """Representations this backend can return.

    A format outside this set raises :class:`UnsupportedFormatError` rather
    than coming back as a different representation under the requested name.
    """

    default_format: ClassVar[ExtractFormat]
    """What this API returns when asked for no format in particular.

    A fact about the backend, not a choice: it is what
    :attr:`~web_router.types.ExtractedDocument.format` reports when the caller
    named none, so getting it wrong mislabels the content.
    """

    batches_urls: ClassVar[bool] = False
    """Whether one call can carry every URL. Most of these APIs take exactly one."""

    # -- What subclasses implement -------------------------------------------

    @abc.abstractmethod
    def _extract(self, request: ExtractRequest, urls: list[str]) -> ExtractResponse:
        """Fetch one call's worth of URLs.

        ``urls`` is every URL the caller asked for when :attr:`batches_urls` is
        set, and a single one otherwise. The request is already validated, and
        the failure of any one call is folded into the whole for you.
        """

    @abc.abstractmethod
    async def _aextract(self, request: ExtractRequest, urls: list[str]) -> ExtractResponse:
        """Async counterpart of :meth:`_extract`."""

    # -- What callers use ----------------------------------------------------

    def extract(self, request: ExtractRequest) -> ExtractResponse:
        """Validate the request, fetch every URL, and wrap any backend failure."""
        self.validate(request)
        collected = _Collected(self.name, request.urls)
        for urls in self._batches(request.urls):
            try:
                collected.add(urls, self._extract(request, urls))
            except ProviderError as exc:
                collected.fail(urls, exc)
            except WebRouterError:
                raise
            except Exception as exc:
                collected.fail(urls, self._failure(exc))
        return collected.resolved()

    async def aextract(self, request: ExtractRequest) -> ExtractResponse:
        """Async counterpart of :meth:`extract`.

        The calls run concurrently, up to
        :data:`~web_router.constants.MAX_CONCURRENT_EXTRACTS` at a time.
        """
        self.validate(request)
        batches = self._batches(request.urls)
        limit = asyncio.Semaphore(MAX_CONCURRENT_EXTRACTS)

        async def _one(urls: list[str]) -> ExtractResponse:
            async with limit:
                return await self._aextract(request, urls)

        outcomes = await asyncio.gather(*(_one(urls) for urls in batches), return_exceptions=True)

        collected = _Collected(self.name, request.urls)
        for urls, outcome in zip(batches, outcomes, strict=True):
            if isinstance(outcome, ExtractResponse):
                collected.add(urls, outcome)
            elif isinstance(outcome, ProviderError):
                collected.fail(urls, outcome)
            elif isinstance(outcome, WebRouterError) or not isinstance(outcome, Exception):
                raise outcome
            else:
                collected.fail(urls, self._failure(outcome))
        return collected.resolved()

    def validate(self, request: ExtractRequest) -> None:
        """Raise for any option this backend does not map, or format it cannot return."""
        self._reject_unmapped(request)
        if request.format is not None and request.format not in self.supported_formats:
            raise UnsupportedFormatError(self.name, request.format, self.supported_formats)

    # -- Helpers for subclasses ----------------------------------------------

    def format_of(self, request: ExtractRequest) -> ExtractFormat:
        """What this call will return: the format asked for, else this API's own default.

        Providers send this to their API rather than omitting the field when the
        caller named nothing, which is the one place the "unset means unset"
        rule is deliberately not applied: the value sent *is* the backend's own
        default, so nothing about the call changes, but
        :attr:`~web_router.ExtractedDocument.format` is then true because it was
        asked for rather than true because a vendor default has not moved.
        """
        return request.format or self.default_format

    def _batches(self, urls: list[str]) -> list[list[str]]:
        return [list(urls)] if self.batches_urls else [[url] for url in urls]

    def _failure(self, exc: BaseException) -> ProviderError:
        return ProviderError(self.name, MSG_EXTRACT_FAILED.format(error=exc), original=exc)


class _Collected:
    """One extract call's outcome, accumulated across however many API calls it took."""

    def __init__(self, provider: str, requested: list[str]) -> None:
        self.provider = provider
        self.requested = requested
        # Whoever actually answered, which is not always `provider`: `auto`
        # delegates, and the response must name the backend that served the
        # call rather than the one that chose it.
        self.served_by: str | None = None
        self.documents: list[ExtractedDocument] = []
        self.failures: list[ExtractFailure] = []
        self.payloads: list[dict[str, Any]] = []
        self.request_id: str | None = None
        self.errors: list[tuple[list[str], ProviderError]] = []

    def add(self, urls: list[str], response: ExtractResponse) -> None:
        self.served_by = self.served_by or response.provider
        self.documents.extend(response.documents)
        self.failures.extend(response.failures)
        self.payloads.extend(response.raw or [])
        self.request_id = self.request_id or response.request_id
        self._account_for(urls, response)

    def _account_for(self, urls: list[str], response: ExtractResponse) -> None:
        """Report any URL of this call the backend mentioned neither way.

        A backend can answer 200 with a payload its mapping did not expect --
        Oxylabs returns no result tagged with the format asked for, a batching
        backend leaves a URL out of its list -- and the URL would otherwise
        vanish from a call that partly succeeded. Only reached when fewer items
        came back than URLs went out, so a backend that canonicalizes the URL it
        echoes is not mistaken for one that dropped it.
        """
        if len(response.documents) + len(response.failures) >= len(urls):
            return

        mentioned = {document.url for document in response.documents} | {failure.url for failure in response.failures}
        self.failures.extend(
            ExtractFailure(url=url, error=MSG_EXTRACT_NO_DOCUMENT) for url in urls if url not in mentioned
        )

    def fail(self, urls: list[str], error: ProviderError) -> None:
        """Record a call that raised as a failure against each URL it carried."""
        self.errors.append((urls, error))
        self.failures.extend(ExtractFailure(url=url, error=str(error)) for url in urls)

    def resolved(self) -> ExtractResponse:
        # Not `if self.failures`: a backend can also answer successfully with
        # nothing in it, and an empty response is the one outcome a caller
        # cannot distinguish from a page that had no text.
        if not self.documents:
            raise self._exhausted()
        return ExtractResponse(
            provider=self.served_by or self.provider,
            documents=self._in_request_order(),
            failures=self.failures,
            request_id=self.request_id,
            raw=self.payloads or None,
        )

    def _in_request_order(self) -> list[ExtractedDocument]:
        """The documents in the order the caller asked for their URLs.

        The fan-out answers in order already, but a backend taking every URL at
        once answers in its own -- so without this, which backend served the
        call would be visible in the order of the result. Keyed on the URL as it
        was asked for: a backend that canonicalizes what it echoes matches
        nothing here and keeps its arrival order, which for a one-URL-per-call
        backend is the caller's order anyway.
        """
        position = {url: index for index, url in enumerate(self.requested)}
        if not all(document.url in position for document in self.documents):
            return self.documents
        return sorted(self.documents, key=lambda document: position[document.url])

    def _exhausted(self) -> ProviderError:
        """Say why nothing came back.

        When everything that failed came from a single call, that call's own
        error is raised untouched -- so extracting one URL through a backend
        with a bad credential reports the 401, not a summary of one.
        """
        if len(self.errors) == 1:
            urls, error = self.errors[0]
            if len(self.failures) == len(urls):
                return error

        failures = self.failures or [ExtractFailure(url=url, error=MSG_EXTRACT_NO_DOCUMENT) for url in self.requested]
        detail = "; ".join(f"{failure.url}: {failure.error}" for failure in failures)
        original = self.errors[0][1].original if self.errors else None
        return ProviderError(self.provider, MSG_EXTRACT_NOTHING_RETURNED.format(failures=detail), original=original)
