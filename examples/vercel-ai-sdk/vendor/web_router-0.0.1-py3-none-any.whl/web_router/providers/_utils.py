"""Helpers shared by provider implementations."""

from __future__ import annotations

import os
from collections.abc import Mapping
from typing import Any

from web_router.constants import SNIPPET_LIMIT
from web_router.exceptions import ConfigurationError
from web_router.types import NormalizedRequest


def resolve_api_key(api_key: str | None, *, env_var: str, provider: str) -> str:
    """Return the explicit key, else the one in ``env_var``.

    Raises:
        ConfigurationError: if neither is available, naming the variable to set.
    """
    key = api_key or os.environ.get(env_var)
    if not key:
        raise ConfigurationError.missing_api_key(provider, env_var)
    return key


def resolve_setting(value: str | None, *, env_var: str, provider: str, setting: str) -> str:
    """Return the explicit value of a required non-credential setting, else the one in ``env_var``.

    Raises:
        ConfigurationError: if neither is available, naming the variable to set.
    """
    resolved = value or os.environ.get(env_var)
    if not resolved:
        raise ConfigurationError.missing_setting(provider, env_var=env_var, setting=setting)
    return resolved


def build_payload(
    request: NormalizedRequest,
    names: Mapping[str, str] | None = None,
    /,
    **fixed: Any,
) -> dict[str, Any]:
    """Assemble a provider payload from the options it maps.

    Args:
        request: The normalized request.
        names: Normalized parameter -> this provider's field name. Omitted by a
            provider whose every option maps onto a table rather than a rename,
            which is every extract backend so far. Positional-only, so a payload
            field of any type can be passed as a keyword without colliding
            with it.
        **fixed: Fields the provider always sends, such as the query itself, or
            ones it derives (a depth or format mapping, say). ``None`` values are
            dropped, so a derived field that does not apply can be passed
            unconditionally.

    Every provider builds its payload through here, which is what guarantees two
    things a new provider would otherwise have to remember: unset options are
    never sent, and ``provider_options`` always reaches the API last so it can
    override anything above it.
    """
    mapped = {theirs: getattr(request, ours) for ours, theirs in (names or {}).items()}
    payload = compact({**fixed, **mapped})
    payload.update(request.provider_options)
    return payload


def model_to_dict(model: Any) -> dict[str, Any]:
    """Convert an SDK response model to a plain dict, across pydantic v1 and v2."""
    for method in ("model_dump", "dict"):
        dump = getattr(model, method, None)
        if callable(dump):
            result: dict[str, Any] = dump()
            return result
    return dict(model)


def compact(mapping: dict[str, Any]) -> dict[str, Any]:
    """Drop ``None`` values so unset parameters never reach the provider."""
    return {key: value for key, value in mapping.items() if value is not None}


def best_text(body: str | None, description: str | None) -> str:
    """Pick the fullest text a result offers.

    Providers disagree about where the body lands: Nimble returns an enriched
    ``description`` and an empty ``content`` at mid depths, Tavily separates
    ``content`` from ``raw_content``, You.com nests it under ``contents``.
    Normalizing here keeps ``SearchResult.content`` meaning the same thing
    whichever backend served the query.
    """
    return body or description or ""


def as_snippet(text: str) -> str:
    """Shorten body text to something the size of a snippet.

    For providers that return page content but no summary, so ``description``
    means the same thing everywhere. Breaks on whitespace to avoid cutting a
    word in half.
    """
    if len(text) <= SNIPPET_LIMIT:
        return text
    head = text[:SNIPPET_LIMIT]
    cut = head.rfind(" ")
    return (head[:cut] if cut > 0 else head).rstrip() + "\u2026"
