"""Nimble providers, backed by the official ``nimble-python`` SDK.

Search and extract are separate classes over one SDK client: the Search API
ranks the web, the Extract API fetches a page you already have the URL of.
Install with ``pip install 'web-router[search]'`` or ``[extract]``. Both read
``NIMBLE_API_KEY`` unless a key is passed explicitly.
"""

from __future__ import annotations

from typing import Any, ClassVar

from nimble_python import AsyncNimble, Nimble

from web_router.constants import (
    ENV_NIMBLE_API_KEY,
    MSG_EXTRACT_BAD_STATUS,
    NIMBLE_EXTRACT_DEFAULT_FORMAT,
    NIMBLE_EXTRACT_FORMATS,
    NIMBLE_EXTRACT_SUCCESS_STATUS,
    NIMBLE_PARAM_NAMES,
    NIMBLE_PARAMS_BY_DEPTH,
    PROVIDER_NIMBLE,
)
from web_router.providers._utils import best_text, build_payload, compact, model_to_dict, resolve_api_key
from web_router.providers.base import ExtractProvider, SearchProvider
from web_router.types import (
    EXTRACT_PARAMETERS,
    NORMALIZED_PARAMETERS,
    ExtractedDocument,
    ExtractFailure,
    ExtractFormat,
    ExtractRequest,
    ExtractResponse,
    SearchRequest,
    SearchResponse,
    SearchResult,
)


class NimbleProvider(SearchProvider):
    """Routes searches to the Nimble Search API."""

    name: ClassVar[str] = PROVIDER_NIMBLE
    supported_parameters: ClassVar[frozenset[str]] = NORMALIZED_PARAMETERS

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> None:
        key = resolve_api_key(api_key, env_var=ENV_NIMBLE_API_KEY, provider=self.name)
        super().__init__(api_key=key, base_url=base_url, timeout=timeout, **kwargs)

        client_kwargs = compact({**self.options, "api_key": key})
        self._client = Nimble(**client_kwargs)
        self._async_client = AsyncNimble(**client_kwargs)

    def _search(self, request: SearchRequest) -> SearchResponse:
        raw = self._client.search(**self._build_payload(request))
        return self._to_response(request, model_to_dict(raw))

    async def _asearch(self, request: SearchRequest) -> SearchResponse:
        raw = await self._async_client.search(**self._build_payload(request))
        return self._to_response(request, model_to_dict(raw))

    def close(self) -> None:
        self._client.close()

    async def aclose(self) -> None:
        await self._async_client.close()

    def _build_payload(self, request: SearchRequest) -> dict[str, Any]:
        """Translate a normalized request into Nimble ``search()`` keyword arguments."""
        depth = NIMBLE_PARAMS_BY_DEPTH[request.search_depth] if request.search_depth else {}
        return build_payload(request, NIMBLE_PARAM_NAMES, query=request.query, **depth)

    def _to_response(self, request: SearchRequest, payload: dict[str, Any]) -> SearchResponse:
        results = []
        for item in payload.get("results") or []:
            additional = item.get("additional_data") or {}
            description = item.get("description") or ""
            results.append(
                SearchResult(
                    url=item.get("url", ""),
                    title=item.get("title") or "",
                    description=description,
                    content=best_text(item.get("content"), description),
                    published_date=additional.get("publish_date") or additional.get("published_date"),
                    extra={"metadata": item.get("metadata") or {}, **additional},
                )
            )

        return SearchResponse(
            provider=self.name,
            query=request.query,
            results=results,
            answer=payload.get("answer"),
            request_id=payload.get("request_id"),
            raw=payload,
        )


class NimbleExtractProvider(ExtractProvider):
    """Fetches page contents through the Nimble Extract API."""

    name: ClassVar[str] = PROVIDER_NIMBLE
    supported_parameters: ClassVar[frozenset[str]] = EXTRACT_PARAMETERS
    supported_formats: ClassVar[frozenset[ExtractFormat]] = frozenset(NIMBLE_EXTRACT_FORMATS)
    default_format: ClassVar[ExtractFormat] = NIMBLE_EXTRACT_DEFAULT_FORMAT

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> None:
        key = resolve_api_key(api_key, env_var=ENV_NIMBLE_API_KEY, provider=self.name)
        super().__init__(api_key=key, base_url=base_url, timeout=timeout, **kwargs)

        client_kwargs = compact({**self.options, "api_key": key})
        self._client = Nimble(**client_kwargs)
        self._async_client = AsyncNimble(**client_kwargs)

    def _extract(self, request: ExtractRequest, urls: list[str]) -> ExtractResponse:
        raw = self._client.extract.run(**self._build_payload(request, urls))
        return self._to_response(request, urls, model_to_dict(raw))

    async def _aextract(self, request: ExtractRequest, urls: list[str]) -> ExtractResponse:
        raw = await self._async_client.extract.run(**self._build_payload(request, urls))
        return self._to_response(request, urls, model_to_dict(raw))

    def close(self) -> None:
        self._client.close()

    async def aclose(self) -> None:
        await self._async_client.close()

    def _build_payload(self, request: ExtractRequest, urls: list[str]) -> dict[str, Any]:
        """Translate a normalized request into Nimble ``extract.run()`` keyword arguments."""
        return build_payload(request, url=urls[0], formats=[NIMBLE_EXTRACT_FORMATS[self.format_of(request)]])

    def _to_response(self, request: ExtractRequest, urls: list[str], payload: dict[str, Any]) -> ExtractResponse:
        # Nimble echoes the URL it resolved to, which is the better label; this
        # call's own URL stands in so a failure always names something.
        url = payload.get("url") or urls[0]
        status = payload.get("status")
        data = payload.get("data") or {}

        # Nimble answers 200 and says in `status` whether it got the page, so a
        # block or a fatal fetch error arrives as a successful call carrying no
        # content. Reporting that as an empty document would hide it.
        if status != NIMBLE_EXTRACT_SUCCESS_STATUS:
            detail = MSG_EXTRACT_BAD_STATUS.format(status=status)
            failure = ExtractFailure(url=url, error="; ".join([detail, *(payload.get("warnings") or [])]))
            return ExtractResponse(provider=self.name, failures=[failure], raw=[payload])

        body_format = self.format_of(request)
        body_field = NIMBLE_EXTRACT_FORMATS[body_format]
        document = ExtractedDocument(
            url=url,
            content=data.get(body_field) or "",
            format=body_format,
            status_code=_as_int(payload.get("status_code")),
            # Read rather than popped: `data` is `payload["data"]`, and taking
            # the body out of it would take it out of `raw` too.
            extra=compact({"metadata": payload.get("metadata"), **{k: v for k, v in data.items() if k != body_field}}),
        )

        return ExtractResponse(
            provider=self.name,
            documents=[document],
            request_id=payload.get("task_id"),
            raw=[payload],
        )


def _as_int(value: Any) -> int | None:
    """Nimble types its status code as a number and sends it as ``200.0``."""
    return None if value is None else int(value)
