"""The providers used when the caller named none, one per method.

Tries providers in order and returns the first answer: the ones you have a
credential for first, then the keyless tiers. A key in the environment says
which backend you want, so reaching for an anonymous rate-limited tier while
one sits configured would be perverse -- but with no key at all the router
still searches, rather than raising about a credential nobody mentioned.

The order is fixed rather than random. A router that picked a different backend
each run would return different result counts and content lengths for the same
query, and a bug reported against it could not be reproduced -- in a package
whose promise is that a query behaves the same whichever backend serves it, the
backend is the last thing that should be a coin flip. The chain still delivers
what a random pick was reaching for: when one anonymous tier is rate-limited,
the next one answers.

``SearchResponse.provider`` and ``ExtractResponse.provider`` name the backend
that actually served the call, never ``"auto"``, so a caller can always tell who
answered.
"""

from __future__ import annotations

from typing import Any, ClassVar

from web_router.constants import (
    AUTO_AGGREGATE_FAILURE,
    AUTO_EXTRA,
    AUTO_EXTRACT_DEFAULT_FORMAT,
    AUTO_EXTRACT_FORMATS,
    AUTO_EXTRACT_KEYLESS,
    AUTO_EXTRACT_PREFERRED,
    AUTO_KEYLESS,
    AUTO_PREFERRED,
    AUTO_SUPPORTED_PARAMETERS,
    PROVIDER_AUTO,
)
from web_router.exceptions import ConfigurationError, ProviderError, ProviderNotInstalledError, WebRouterError
from web_router.providers.base import ExtractProvider, SearchProvider
from web_router.types import (
    EXTRACT_PARAMETERS,
    ExtractFormat,
    ExtractRequest,
    ExtractResponse,
    SearchRequest,
    SearchResponse,
)

_RECOVERABLE = (ProviderNotInstalledError, ConfigurationError, ProviderError)
"""Failures that mean "try the next backend".

A missing extra, a missing credential and a backend that refused the call are
all things another member of the chain may not suffer from. Anything else --
notably :class:`UnsupportedParameterError` -- is a bug in this class rather
than a property of the backend, and propagates.
"""


def _keyed_chain(preferred: tuple[str, ...], configured: set[str]) -> tuple[tuple[str, dict[str, Any]], ...]:
    """The preferred backends you actually hold credentials for, in order."""
    return tuple((name, {}) for name in preferred if name in configured)


def _exhausted(provider: str, failures: dict[str, WebRouterError]) -> WebRouterError:
    """Report every backend's own reason, so the cause is not hidden behind "auto"."""
    # Nothing installed is a setup problem with one fix, not a row of backend
    # failures to read through. Say so in the form that names it.
    if failures and all(isinstance(exc, ProviderNotInstalledError) for exc in failures.values()):
        return ProviderNotInstalledError(provider, AUTO_EXTRA)

    detail = "; ".join(f"{name}: {exc}" for name, exc in failures.items())
    return ProviderError(provider, AUTO_AGGREGATE_FAILURE.format(failures=detail))


class AutoProvider(SearchProvider):
    """Searches through the first backend that answers, credentialed ones first."""

    name: ClassVar[str] = PROVIDER_AUTO
    supported_parameters: ClassVar[frozenset[str]] = AUTO_SUPPORTED_PARAMETERS

    def __init__(self, *, chain: tuple[tuple[str, dict[str, Any]], ...] | None = None, **kwargs: Any) -> None:
        """
        Args:
            chain: Backends to try, in order, as ``(provider name, kwargs)``.
                Defaults to :meth:`default_chain` for the current environment.
            **kwargs: Ignored. Accepted so a router configured for several
                providers can hand this one its config without special-casing.
        """
        super().__init__(**kwargs)
        self._chain = self.default_chain() if chain is None else chain
        # Keyed by position, not by name: the same provider can appear twice on
        # different terms -- Tavily keyed, then Tavily keyless.
        self._members: dict[int, SearchProvider] = {}

    @staticmethod
    def default_chain() -> tuple[tuple[str, dict[str, Any]], ...]:
        """Providers you have a credential for, then the keyless ones."""
        from web_router.registry import configured_providers

        return _keyed_chain(AUTO_PREFERRED, set(configured_providers())) + AUTO_KEYLESS

    def _member(self, position: int) -> SearchProvider:
        """Build and cache one member. Imported here so the chain stays lazy."""
        from web_router.registry import create_provider

        if position not in self._members:
            provider_name, options = self._chain[position]
            self._members[position] = create_provider(provider_name, **options)
        return self._members[position]

    def _search(self, request: SearchRequest) -> SearchResponse:
        failures: dict[str, WebRouterError] = {}
        for position, (provider_name, _) in enumerate(self._chain):
            try:
                return self._member(position).search(request)
            except _RECOVERABLE as exc:
                failures[provider_name] = exc
        raise _exhausted(self.name, failures)

    async def _asearch(self, request: SearchRequest) -> SearchResponse:
        failures: dict[str, WebRouterError] = {}
        for position, (provider_name, _) in enumerate(self._chain):
            try:
                return await self._member(position).asearch(request)
            except _RECOVERABLE as exc:
                failures[provider_name] = exc
        raise _exhausted(self.name, failures)

    def close(self) -> None:
        for member in self._members.values():
            member.close()

    async def aclose(self) -> None:
        for member in self._members.values():
            await member.aclose()


class AutoExtractProvider(ExtractProvider):
    """Extracts through the first backend that answers, credentialed ones first."""

    name: ClassVar[str] = PROVIDER_AUTO
    supported_parameters: ClassVar[frozenset[str]] = EXTRACT_PARAMETERS
    supported_formats: ClassVar[frozenset[ExtractFormat]] = AUTO_EXTRACT_FORMATS
    default_format: ClassVar[ExtractFormat] = AUTO_EXTRACT_DEFAULT_FORMAT
    # The members each batch as their own API allows, so there is nothing to
    # split up here: one delegated call carries the whole request.
    batches_urls: ClassVar[bool] = True

    def __init__(self, *, chain: tuple[tuple[str, dict[str, Any]], ...] | None = None, **kwargs: Any) -> None:
        """
        Args:
            chain: Backends to try, in order, as ``(provider name, kwargs)``.
                Defaults to :meth:`default_chain` for the current environment.
            **kwargs: Ignored, as on :class:`AutoProvider`.
        """
        super().__init__(**kwargs)
        self._chain = self.default_chain() if chain is None else chain
        self._members: dict[int, ExtractProvider] = {}

    @staticmethod
    def default_chain() -> tuple[tuple[str, dict[str, Any]], ...]:
        """Backends you have credentials for, then the keyless ones."""
        from web_router.registry import configured_extract_providers

        return _keyed_chain(AUTO_EXTRACT_PREFERRED, set(configured_extract_providers())) + AUTO_EXTRACT_KEYLESS

    def _member(self, position: int) -> ExtractProvider:
        """Build and cache one member. Imported here so the chain stays lazy."""
        from web_router.registry import create_extract_provider

        if position not in self._members:
            provider_name, options = self._chain[position]
            self._members[position] = create_extract_provider(provider_name, **options)
        return self._members[position]

    def _extract(self, request: ExtractRequest, urls: list[str]) -> ExtractResponse:
        delegated = self._delegated(request, urls)
        failures: dict[str, WebRouterError] = {}
        for position, (provider_name, _) in enumerate(self._chain):
            try:
                return self._member(position).extract(delegated)
            except _RECOVERABLE as exc:
                failures[provider_name] = exc
        raise _exhausted(self.name, failures)

    async def _aextract(self, request: ExtractRequest, urls: list[str]) -> ExtractResponse:
        delegated = self._delegated(request, urls)
        failures: dict[str, WebRouterError] = {}
        for position, (provider_name, _) in enumerate(self._chain):
            try:
                return await self._member(position).aextract(delegated)
            except _RECOVERABLE as exc:
                failures[provider_name] = exc
        raise _exhausted(self.name, failures)

    def _delegated(self, request: ExtractRequest, urls: list[str]) -> ExtractRequest:
        """The request to hand a member, with the format named explicitly.

        The members disagree about their own defaults -- Nimble returns HTML,
        Tavily markdown -- so letting one fall through would make the shape of
        the content depend on which backend happened to answer.
        """
        return request.model_copy(update={"format": self.format_of(request), "urls": urls})

    def close(self) -> None:
        for member in self._members.values():
            member.close()

    async def aclose(self) -> None:
        for member in self._members.values():
            await member.aclose()
