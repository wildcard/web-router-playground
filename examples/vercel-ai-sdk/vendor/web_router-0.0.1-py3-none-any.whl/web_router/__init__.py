"""web-router: one interface over many web search and page-extraction APIs.

Point the router at a provider and call it; swapping backends is a one-word
change rather than a rewrite.

    >>> from web_router import WebRouter
    >>> router = WebRouter("nimble")
    >>> response = router.search("what is retrieval augmented generation", max_results=5)
    >>> pages = router.extract(response.urls[:3], format="markdown")
"""

from web_router._version import __version__
from web_router.client import AsyncWebRouter, WebRouter
from web_router.constants import DEFAULT_PROVIDER
from web_router.exceptions import (
    ConfigurationError,
    ProviderError,
    ProviderNotFoundError,
    ProviderNotInstalledError,
    UnsupportedFormatError,
    UnsupportedParameterError,
    WebRouterError,
)
from web_router.providers.base import ExtractProvider, SearchProvider
from web_router.registry import (
    available_extract_providers,
    available_providers,
    configured_extract_providers,
    configured_providers,
    register_extract_provider,
    register_provider,
    unregister_extract_provider,
    unregister_provider,
)
from web_router.types import (
    EXTRACT_PARAMETERS,
    NORMALIZED_PARAMETERS,
    ExtractedDocument,
    ExtractFailure,
    ExtractFormat,
    ExtractRequest,
    ExtractResponse,
    Provider,
    SearchDepth,
    SearchRequest,
    SearchResponse,
    SearchResult,
)

__all__ = [
    "DEFAULT_PROVIDER",
    "EXTRACT_PARAMETERS",
    "NORMALIZED_PARAMETERS",
    "AsyncWebRouter",
    "ConfigurationError",
    "ExtractFailure",
    "ExtractFormat",
    "ExtractProvider",
    "ExtractRequest",
    "ExtractResponse",
    "ExtractedDocument",
    "Provider",
    "ProviderError",
    "ProviderNotFoundError",
    "ProviderNotInstalledError",
    "SearchDepth",
    "SearchProvider",
    "SearchRequest",
    "SearchResponse",
    "SearchResult",
    "UnsupportedFormatError",
    "UnsupportedParameterError",
    "WebRouter",
    "WebRouterError",
    "__version__",
    "available_extract_providers",
    "available_providers",
    "configured_extract_providers",
    "configured_providers",
    "register_extract_provider",
    "register_provider",
    "unregister_extract_provider",
    "unregister_provider",
]
