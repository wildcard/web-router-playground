"""Every exception web-router raises.

Provider SDKs raise their own error types. The router wraps them so callers can
handle failures uniformly regardless of which backend served the request:

    WebRouterError
    ├── ConfigurationError          bad or missing configuration
    ├── ProviderNotFoundError       no provider registered under that name
    ├── ProviderNotInstalledError   provider known, optional dependency missing
    ├── UnsupportedParameterError   provider does not map a requested parameter
    ├── UnsupportedFormatError      provider cannot return a requested format
    └── ProviderError               the backend itself failed

Message text lives in :mod:`web_router.constants`.
"""

from __future__ import annotations

from collections.abc import Iterable

from web_router.constants import (
    MSG_MISSING_SETTING,
    MSG_NO_API_KEY,
    MSG_PROVIDER_NOT_INSTALLED,
    MSG_UNKNOWN_PROVIDER,
    MSG_UNSUPPORTED_FORMAT,
    MSG_UNSUPPORTED_PARAMETERS,
)


class WebRouterError(Exception):
    """Base class for every error raised by web-router."""


class ConfigurationError(WebRouterError):
    """The router or a provider was configured incorrectly."""

    @classmethod
    def missing_api_key(cls, provider: str, env_var: str) -> ConfigurationError:
        """Build the error for a provider with no usable credential."""
        return cls(MSG_NO_API_KEY.format(provider=provider, env_var=env_var))

    @classmethod
    def missing_setting(cls, provider: str, *, env_var: str, setting: str) -> ConfigurationError:
        """Build the error for a required setting that is not a credential.

        Oxylabs authenticates with a username beside its key, and Bright Data
        routes through a zone you create in its console. Neither has a default
        worth guessing, so both are named the same way a missing key is.
        """
        return cls(MSG_MISSING_SETTING.format(provider=provider, env_var=env_var, setting=setting))


class ProviderNotFoundError(WebRouterError):
    """A provider was requested by a name that is not registered."""

    def __init__(self, name: str, available: Iterable[str]) -> None:
        self.name = name
        # Deduplicated: the router looks a default up in both method registries,
        # and a provider serving both would otherwise be listed twice.
        self.available = sorted(set(available))
        super().__init__(MSG_UNKNOWN_PROVIDER.format(name=name, available=", ".join(self.available)))


class ProviderNotInstalledError(WebRouterError):
    """A provider is registered but its optional dependency is not installed."""

    def __init__(self, name: str, extra: str) -> None:
        self.name = name
        self.extra = extra
        super().__init__(MSG_PROVIDER_NOT_INSTALLED.format(name=name, extra=extra))


class UnsupportedParameterError(WebRouterError):
    """A request set a parameter the chosen provider does not map.

    Raised rather than dropping the parameter, so a query never runs under
    weaker constraints than the caller asked for. The message points at
    ``provider_options`` and at adding the mapping, because for a deliberately
    minimal provider this usually means "not mapped yet" rather than
    "impossible".
    """

    def __init__(self, provider: str, parameters: Iterable[str]) -> None:
        self.provider = provider
        self.parameters = sorted(parameters)
        names = ", ".join(repr(name) for name in self.parameters)
        super().__init__(MSG_UNSUPPORTED_PARAMETERS.format(provider=provider, names=names))


class UnsupportedFormatError(WebRouterError):
    """A request asked for an output format the chosen provider cannot return.

    Separate from :class:`UnsupportedParameterError`: the provider does map
    ``format``, it just cannot produce this one. Raised rather than returning a
    different representation under the requested name, because a caller feeding
    the result to a markdown parser would otherwise get HTML and no warning.
    """

    def __init__(self, provider: str, requested: str, supported: Iterable[str]) -> None:
        self.provider = provider
        self.requested = requested
        self.supported = sorted(supported)
        super().__init__(
            MSG_UNSUPPORTED_FORMAT.format(
                provider=provider,
                requested=requested,
                supported=", ".join(repr(name) for name in self.supported) or "nothing",
            )
        )


class ProviderError(WebRouterError):
    """A provider failed while serving a request.

    The original SDK or HTTP exception is available as :attr:`original` and as
    ``__cause__``.
    """

    def __init__(self, provider: str, message: str, *, original: BaseException | None = None) -> None:
        super().__init__(f"[{provider}] {message}")
        self.provider = provider
        self.original = original
