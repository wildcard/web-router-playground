"""Every literal the package depends on.

Endpoints, environment variable names, timeouts and message templates live here
rather than inline, so a provider's wire details can be reviewed in one place
and changed without touching logic.
"""

from __future__ import annotations

from typing import Any

from web_router.types import NORMALIZED_PARAMETERS, ExtractFormat, Provider, SearchDepth

# --- Router -----------------------------------------------------------------

# Plain strings, taken from the enum so the names are defined exactly once.
PROVIDER_NIMBLE = Provider.NIMBLE.value
PROVIDER_TAVILY = Provider.TAVILY.value
PROVIDER_YOU = Provider.YOU.value
PROVIDER_BRAVE = Provider.BRAVE.value
PROVIDER_EXA = Provider.EXA.value
PROVIDER_PARALLEL = Provider.PARALLEL.value
PROVIDER_PERPLEXITY = Provider.PERPLEXITY.value
PROVIDER_YOU_MCP = Provider.YOU_MCP.value
PROVIDER_OXYLABS = Provider.OXYLABS.value
PROVIDER_BRIGHTDATA = Provider.BRIGHTDATA.value
PROVIDER_FIRECRAWL = Provider.FIRECRAWL.value
PROVIDER_JINA = Provider.JINA.value
PROVIDER_AUTO = Provider.AUTO.value

DEFAULT_PROVIDER = PROVIDER_AUTO
"""Used when the caller names no provider anywhere.

``auto`` needs no credential, so an unconfigured router still searches instead
of raising about a key the caller never mentioned. Naming a provider explicitly
keeps the old behaviour: a missing key for *that* provider is still an error.
"""

# --- Install extras ---------------------------------------------------------

# Extras are named after the methods you call, not the backends behind them, so
# a provider maps to the extra that installs it rather than owning one of its
# own. See the comment over [project.optional-dependencies] in pyproject.toml.
EXTRA_SEARCH = "search"
EXTRA_EXTRACT = "extract"
EXTRA_ALL = "all"

# --- Credentials ------------------------------------------------------------

ENV_NIMBLE_API_KEY = "NIMBLE_API_KEY"
ENV_TAVILY_API_KEY = "TAVILY_API_KEY"
ENV_YOU_API_KEY = "YOU_API_KEY"
ENV_BRAVE_API_KEY = "BRAVE_SEARCH_API_KEY"
ENV_EXA_API_KEY = "EXA_API_KEY"
ENV_PARALLEL_API_KEY = "PARALLEL_API_KEY"
ENV_PERPLEXITY_API_KEY = "PERPLEXITY_API_KEY"
ENV_OXYLABS_USERNAME = "OXYLABS_USERNAME"
ENV_OXYLABS_PASSWORD = "OXYLABS_PASSWORD"
ENV_BRIGHTDATA_API_KEY = "BRIGHTDATA_API_TOKEN"
ENV_BRIGHTDATA_ZONE = "BRIGHTDATA_ZONE"
ENV_FIRECRAWL_API_KEY = "FIRECRAWL_API_KEY"
ENV_JINA_API_KEY = "JINA_API_KEY"

ENV_BY_PROVIDER: dict[str, str | None] = {
    PROVIDER_NIMBLE: ENV_NIMBLE_API_KEY,
    PROVIDER_TAVILY: ENV_TAVILY_API_KEY,
    PROVIDER_YOU: ENV_YOU_API_KEY,
    PROVIDER_BRAVE: ENV_BRAVE_API_KEY,
    PROVIDER_EXA: ENV_EXA_API_KEY,
    PROVIDER_PARALLEL: ENV_PARALLEL_API_KEY,
    PROVIDER_PERPLEXITY: ENV_PERPLEXITY_API_KEY,
    PROVIDER_YOU_MCP: None,
    PROVIDER_AUTO: None,
}
"""Which variable holds each provider's credential; ``None`` means it needs none.

A table rather than a class attribute so :func:`configured_providers` can answer
without importing a single provider module, and with it every optional SDK.
``tests/test_contract.py`` checks it against the registry.

Search only -- :data:`EXTRACT_ENV_BY_PROVIDER` is the same table for extract.
The two are separate because the two method registries are: a name that serves
both appears in each, and one that serves only extract appears in neither this
nor :func:`available_providers`.
"""

EXTRACT_ENV_BY_PROVIDER: dict[str, tuple[str, ...]] = {
    PROVIDER_NIMBLE: (ENV_NIMBLE_API_KEY,),
    PROVIDER_TAVILY: (ENV_TAVILY_API_KEY,),
    PROVIDER_EXA: (ENV_EXA_API_KEY,),
    PROVIDER_FIRECRAWL: (ENV_FIRECRAWL_API_KEY,),
    PROVIDER_OXYLABS: (ENV_OXYLABS_USERNAME, ENV_OXYLABS_PASSWORD),
    PROVIDER_BRIGHTDATA: (ENV_BRIGHTDATA_API_KEY, ENV_BRIGHTDATA_ZONE),
    PROVIDER_JINA: (),
    PROVIDER_AUTO: (),
}
"""Which variables each extract provider needs, all of them; ``()`` means none.

A tuple rather than a single name because two backends need more than a key:
Oxylabs authenticates with a username and password, and Bright Data needs the
zone that routes the request beside its token. ``jina`` needs nothing -- a key
only raises its rate limit -- and ``auto`` needs whatever its chain does.
"""

# --- HTTP defaults, for providers with no SDK -------------------------------

DEFAULT_HTTP_TIMEOUT = 60.0

MAX_CONCURRENT_EXTRACTS = 8
"""How many URLs an async extract fetches at once on a backend taking one per call.

Unbounded, ``aextract`` over a long list would open one connection per URL and
earn a 429 from a call the sync router makes serially without trouble -- the
same request behaving differently for reasons the caller never chose.
"""

FOLLOW_REDIRECTS = False
"""Provider clients never follow redirects, and this is pinned rather than inherited.

httpx replays request headers -- the auth header included -- to the redirect
target, and does not strip them when that target is a different host. A search
endpoint has no legitimate reason to redirect, so following one is either a
misconfiguration or an attempt to collect the credential. Surfacing it as an
error is the safe reading of both. See :data:`MSG_REDIRECTS_WITH_CREDENTIAL`.
"""

MSG_HTTP_ERROR = "HTTP {status}: {body}"

HTTP_ERROR_BODY_LIMIT = 500
"""How much of an error response body to quote back, to keep messages readable."""


# --- Normalization ----------------------------------------------------------

SNIPPET_LIMIT = 500
"""Cap for a description synthesized from body text.

Some providers return no snippet, only page content. Using the head of that
content keeps ``description`` populated without letting a 9 KB excerpt sit in a
field every other provider fills with a sentence or two.
"""

# --- Nimble -----------------------------------------------------------------

NIMBLE_PARAM_NAMES = {name: name for name in NORMALIZED_PARAMETERS - {"search_depth"}}
"""Normalized parameter -> Nimble field. ``search_depth`` maps to two fields, below.

Every other Nimble name already matches the normalized one, so this is an
identity map. It exists so every provider is read the same way: one table per
backend.
"""

NIMBLE_PARAMS_BY_DEPTH: dict[SearchDepth, dict[str, Any]] = {
    # Nimble's declared vocabulary is lite/standard -- a bogus depth returns
    # "Input should be 'lite' or 'standard'". `standard` is a ~2K excerpt; the
    # separate `full_content` flag is what turns it into the whole page.
    # (`deep_search` looks like the match but is deprecated in favour of
    # exactly this pair.)
    #
    # Verified live: Nimble also *tolerates* "fast" and "deep", which this table
    # used to send, as undocumented aliases -- "fast" returns byte-identical
    # results to "standard". They are outside the enum its own validator
    # reports and the SDK types them as invalid, so do not go back to them
    # because they happen to work.
    "lite": {"search_depth": "lite"},
    "fast": {"search_depth": "standard"},
    "deep": {"search_depth": "standard", "full_content": True},
}

NIMBLE_EXTRACT_FORMATS: dict[ExtractFormat, str] = {
    # Normalized format -> the `formats` entry to ask for, which is also the key
    # under `data` the body lands in. Verified live: with no `formats` at all the
    # response carries `data.html` and leaves `data.markdown` null, so `html` is
    # Nimble's own default and NIMBLE_EXTRACT_DEFAULT_FORMAT must agree.
    #
    # Nimble also offers screenshot/headers/links here. They are not page text
    # in another representation, so they are reachable through provider_options
    # rather than mapped onto a format.
    "markdown": "markdown",
    "html": "html",
}

NIMBLE_EXTRACT_DEFAULT_FORMAT: ExtractFormat = "html"

NIMBLE_EXTRACT_SUCCESS_STATUS = "success"
"""The one ``status`` that means the page was fetched.

The others -- ``blocked``, ``fatal``, ``rejected`` and the rest -- arrive with
HTTP 200 and no content, so the status is the only thing that distinguishes a
fetched page from one that was refused.
"""

# --- You.com ----------------------------------------------------------------
# You.com publishes no Python SDK, so the wire details are ours to maintain.

YOU_BASE_URL = "https://ydc-index.io"
YOU_SEARCH_PATH = "/v1/search"
YOU_API_KEY_HEADER = "X-API-Key"
YOU_RESULT_SECTIONS = ("web", "news")
YOU_KNOWLEDGE_ANSWER_TYPE = "answer"

YOU_PARAM_NAMES = {"max_results": "count"}
"""Normalized parameter -> You.com field. ``search_depth`` maps to an object, below.

Kept minimal on purpose: web-router sends You.com only what a search needs. The
rest of its API is reachable through ``provider_options`` and is the obvious
thing for a contributor to map -- see CONTRIBUTING.md.
"""

YOU_EXTRACTION_BY_DEPTH: dict[SearchDepth, dict[str, Any] | None] = {
    # You.com always returns snippets; extraction controls how much page body
    # comes with them. `full_page` yields markdown on its own -- sending the
    # documented `extraction_formats` alongside it is rejected with a 422.
    "lite": None,
    "fast": {"extraction_mode": "highlights"},
    "deep": {"extraction_mode": "full_page"},
}

# --- Tavily -----------------------------------------------------------------

TAVILY_PARAM_NAMES = {"max_results": "max_results"}
"""Normalized parameter -> Tavily field. ``search_depth`` maps to two fields, below.

Kept minimal on purpose: web-router sends Tavily only what a search needs. The
rest of its API is reachable through ``provider_options`` and is the obvious
thing for a contributor to map -- see CONTRIBUTING.md.

One trap for whoever maps ``country`` here: Tavily takes a lowercase country
*name* and rejects the ISO alpha-2 code the shared surface uses and every other
backend requires, so it has to translate rather than pass the value through.
"""

TAVILY_PARAMS_BY_DEPTH: dict[SearchDepth, dict[str, Any]] = {
    # Tavily splits what we call depth across two knobs: search_depth sets how
    # much text each result carries, include_raw_content adds the page body.
    #
    # Two traps here, both of which have already caught this table once:
    # `chunks_per_source` belongs to Tavily's extract and crawl endpoints, not
    # to search -- sending it here rode **kwargs and did nothing, which made
    # `fast` an exact duplicate of `lite` (verified live: byte-identical
    # snippets across every query tried). And Tavily has since grown its own
    # `fast`/`ultra-fast` depths, which are latency tiers rather than content
    # tiers; our `fast` must not be mapped onto them just because it matches.
    #
    # `advanced` buys a modest content bump over `basic` -- roughly +17% of
    # snippet, and steadier across queries -- and costs two API credits rather
    # than one. That is the honest middle rung: Tavily's own step change in
    # volume is raw content, which is what `deep` asks for.
    "lite": {"search_depth": "basic"},
    "fast": {"search_depth": "advanced"},
    "deep": {"search_depth": "advanced", "include_raw_content": "markdown"},
}

TAVILY_EXTRACT_FORMATS: dict[ExtractFormat, str] = {
    # Verified live: `format="html"` is rejected with a 422, and omitting
    # `format` returns the same markdown as asking for it -- so markdown is
    # Tavily's own default and TAVILY_EXTRACT_DEFAULT_FORMAT must agree.
    "markdown": "markdown",
    "text": "text",
}

TAVILY_EXTRACT_DEFAULT_FORMAT: ExtractFormat = "markdown"

TAVILY_EXTRACT_RESULT_FIELD = "raw_content"
"""Where Tavily puts the page body, whichever format it was asked for."""

# --- You.com MCP, the keyless route -----------------------------------------
# A different service from YOU_BASE_URL above: MCP over JSON-RPC rather than
# REST, and open without a credential. The search payload it returns is the
# same shape, which is why YouMcpProvider reuses YouProvider's normalization.

YOU_MCP_BASE_URL = "https://api.you.com"
YOU_MCP_SEARCH_PATH = "/mcp?profile=free"
"""``profile=free`` is the anonymous tier. Verified live: no key, no handshake."""

YOU_MCP_SEARCH_TOOL = "you-search"

YOU_MCP_EXTRACTION_BY_DEPTH: dict[SearchDepth, str] = {
    # The MCP tool takes extraction as a bare enum, where the REST API takes an
    # object -- sending REST's {"extraction_mode": ...} here is rejected as
    # 'expected one of "none"|"highlights"|"full_page"'. `lite` must say "none"
    # rather than stay silent, because this endpoint extracts highlights by
    # default and would otherwise return a full excerpt for the cheapest depth.
    "lite": "none",
    "fast": "highlights",
    "deep": "full_page",
}
YOU_MCP_PROTOCOL_VERSION = "2.0"
YOU_MCP_ACCEPT = "application/json, text/event-stream"
YOU_MCP_SSE_DATA_PREFIX = "data: "

MSG_MCP_ERROR = "MCP call failed: {error}"
MSG_MCP_NO_RESULT = "MCP response carried no result payload"

# --- auto -------------------------------------------------------------------

AUTO_PREFERRED: tuple[str, ...] = (PROVIDER_NIMBLE, PROVIDER_TAVILY, PROVIDER_YOU)
"""Tried first, and only those the caller actually has a credential for.

A key in the environment is a statement that this is the backend you want, so
using an anonymous rate-limited tier instead would be perverse. Every name here
must map at least :data:`AUTO_SUPPORTED_PARAMETERS`, or ``auto`` would accept
an option and then route somewhere that cannot honour it -- which is why the
providers mapping only ``max_results`` are absent.
"""

AUTO_KEYLESS: tuple[tuple[str, dict[str, Any]], ...] = (
    (PROVIDER_TAVILY, {"allow_keyless": True}),
    (PROVIDER_YOU_MCP, {}),
)
"""Tried when no credential is available, in order.

Ordered rather than random on purpose: a router that picks a different backend
each run returns different result counts and content lengths for the same
query, and a bug reported against it cannot be reproduced. The chain still
gives what random was reaching for -- if one anonymous tier is rate-limited,
the next one answers.
"""

AUTO_SUPPORTED_PARAMETERS = frozenset({"max_results", "search_depth"})
"""What every member of the chain maps.

Listed rather than computed so importing ``auto`` does not drag in each
member's SDK. ``tests/test_auto.py`` asserts it really is the intersection.
"""

AUTO_EXTRA = EXTRA_ALL
"""The extra that installs every member of the chain.

``all`` rather than ``search`` because the chain is the fallback of last
resort: when none of its members import, the useful advice is to install
everything, not to guess which method the caller will reach for next.
"""

AUTO_EXTRACT_PREFERRED: tuple[str, ...] = (
    PROVIDER_NIMBLE,
    PROVIDER_TAVILY,
    PROVIDER_FIRECRAWL,
    PROVIDER_OXYLABS,
    PROVIDER_BRIGHTDATA,
)
"""Tried first, and only those the caller actually has credentials for.

Every name here must return :data:`AUTO_EXTRACT_FORMATS`, or ``auto`` would
accept a format and then route somewhere that cannot produce it -- which is why
``exa`` is absent: its extract returns plain text and nothing else.
"""

AUTO_EXTRACT_KEYLESS: tuple[tuple[str, dict[str, Any]], ...] = (
    (PROVIDER_TAVILY, {"allow_keyless": True}),
    (PROVIDER_JINA, {}),
)
"""Tried when no credentials are available, in order. Both verified live keyless."""

AUTO_EXTRACT_FORMATS: frozenset[ExtractFormat] = frozenset({"markdown"})
"""What every member of the chain can return.

Markdown alone: Tavily cannot return HTML and Nimble cannot return plain text,
so it is the only representation the whole chain agrees on. Listed rather than
computed so importing ``auto`` does not drag in each member's SDK.
``tests/test_auto.py`` asserts it really is the intersection.
"""

AUTO_EXTRACT_DEFAULT_FORMAT: ExtractFormat = "markdown"
"""Pinned rather than left to each member's own default.

The members disagree -- Nimble defaults to HTML, Tavily to markdown -- so
letting the default fall through would make ``auto``'s output depend on which
backend answered, which is the one thing this package exists to prevent.
``AutoExtractProvider`` sends this format explicitly when the caller names none.
"""

AUTO_AGGREGATE_FAILURE = "no keyless provider could serve the request: {failures}"

# --- Error messages ---------------------------------------------------------

MSG_NO_API_KEY = (
    "No API key for provider {provider!r}. Set the {env_var} environment variable, "
    "or pass provider_config={{{provider!r}: {{'api_key': ...}}}} when constructing the router."
)

MSG_MISSING_SETTING = (
    "Provider {provider!r} needs a {setting}. Set the {env_var} environment variable, "
    "or pass provider_config={{{provider!r}: {{{setting!r}: ...}}}} when constructing the router."
)

MSG_UNKNOWN_PROVIDER = "Unknown provider {name!r}. Available providers: {available}."

MSG_PROVIDER_NOT_INSTALLED = (
    "Provider {name!r} requires an optional dependency. Install it with: pip install 'web-router[{extra}]'"
)

MSG_UNSUPPORTED_PARAMETERS = (
    "Provider {provider!r} does not map {names}. Pass it through provider_options if the "
    "underlying API supports it, or add the mapping -- see CONTRIBUTING.md."
)

MSG_UNSUPPORTED_FORMAT = (
    "Provider {provider!r} cannot return {requested!r} content; it returns {supported}. Ask for one "
    "of those, name a provider that returns {requested!r}, or add the mapping -- see CONTRIBUTING.md."
)

MSG_SEARCH_FAILED = "search failed: {error}"

MSG_EXTRACT_FAILED = "extract failed: {error}"

MSG_EXTRACT_BAD_STATUS = "the backend fetched nothing and reported status {status!r}"

MSG_EXTRACT_UNSUCCESSFUL = "the backend reported the fetch as unsuccessful and gave no reason"

MSG_EXTRACT_NOTHING_RETURNED = "no URL could be extracted: {failures}"
"""Raised when a call produced no document at all.

A partly successful call returns its failures in ``ExtractResponse.failures``,
but one where nothing came back would otherwise hand back an empty response --
so a bad credential would look like a page with no text.
"""

MSG_EXTRACT_NO_DOCUMENT = "the backend answered without a document for it"
"""Stands in when a backend reports neither a document nor a reason.

Not a case any provider here should reach: it means a payload was shaped in a
way its mapping did not expect. Saying so beats returning an empty response.
"""

MSG_REDIRECTS_WITH_CREDENTIAL = (
    "Provider {provider!r} refuses follow_redirects=True while it is sending a credential. "
    "httpx replays request headers to the redirect target without stripping them, so a redirect "
    "to another host would hand that host your API key. Point base_url at the host you mean to "
    "call instead."
)

# TODO: remove once benchmark() is implemented on the routers.
MSG_NOT_IMPLEMENTED = (
    "{method} is not implemented yet -- it is a placeholder for a planned capability. "
    "Use search() or extract() meanwhile."
)


# --- Brave ------------------------------------------------------------------

BRAVE_BASE_URL = "https://api.search.brave.com"
BRAVE_SEARCH_PATH = "/res/v1/web/search"
BRAVE_API_KEY_HEADER = "X-Subscription-Token"
BRAVE_PARAM_NAMES = {"max_results": "count"}
BRAVE_HIGHLIGHT_TAGS = ("<strong>", "</strong>")
"""Brave wraps query terms in these; they are its markup, not page content."""

# --- Exa --------------------------------------------------------------------

EXA_BASE_URL = "https://api.exa.ai"
EXA_SEARCH_PATH = "/search"
EXA_API_KEY_HEADER = "x-api-key"
EXA_PARAM_NAMES = {"max_results": "numResults"}
EXA_CONTENTS = {"text": True}
"""Exa returns links only unless contents are requested, so ask for text.

Not an enrichment: without it ``SearchResult.content`` would always be empty,
which every other provider fills.
"""

EXA_CONTENTS_PATH = "/contents"

EXA_EXTRACT_FORMATS: dict[ExtractFormat, dict[str, Any]] = {
    # Exa returns one representation of a page and calls it `text`, so this
    # table has a single row -- which is the point of having it: asking Exa for
    # markdown raises instead of handing back text under the wrong name.
    #
    # Spelled out rather than reusing EXA_CONTENTS above: search nests that
    # under `contents` while /contents takes the same field at the top level,
    # so sharing one constant would put any field added for search into every
    # extract body.
    "text": {"text": True},
}

EXA_EXTRACT_DEFAULT_FORMAT: ExtractFormat = "text"

# --- Parallel ---------------------------------------------------------------

PARALLEL_BASE_URL = "https://api.parallel.ai"
PARALLEL_SEARCH_PATH = "/v1beta/search"
"""The beta endpoint, because only it honors max_results -- verified live; /v1 rejects it."""

PARALLEL_API_KEY_HEADER = "x-api-key"
PARALLEL_PARAM_NAMES = {"max_results": "max_results"}

# --- Perplexity -------------------------------------------------------------

PERPLEXITY_BASE_URL = "https://api.perplexity.ai"
PERPLEXITY_SEARCH_PATH = "/search"
PERPLEXITY_API_KEY_HEADER = "Authorization"
PERPLEXITY_API_KEY_PREFIX = "Bearer "
PERPLEXITY_PARAM_NAMES = {"max_results": "max_results"}


# --- Oxylabs ----------------------------------------------------------------
# Extract only: Oxylabs' Web Scraper API fetches a URL, it does not rank the web.
# Mapped from documentation -- no account was available to verify it live. See
# tests/providers/test_oxylabs.py.

OXYLABS_BASE_URL = "https://realtime.oxylabs.io"
OXYLABS_EXTRACT_PATH = "/v1/queries"
"""The realtime endpoint, the only one that returns content in the response.

The push-pull endpoint at ``data.oxylabs.io`` submits a job and hands back an id
to poll, which is a different shape of integration than ``extract()`` promises.
"""

OXYLABS_UNIVERSAL_SOURCE = "universal"
"""The ``source`` that means "any website", as opposed to a per-site parser."""

OXYLABS_MARKDOWN_PARAM = "markdown"

OXYLABS_EXTRACT_FORMATS: dict[ExtractFormat, str] = {
    # Normalized format -> the `type` Oxylabs tags the matching result with. A
    # request can ask for several representations at once and each comes back as
    # its own entry in `results`, in no guaranteed order, so the reply is picked
    # by `type` rather than by position.
    "html": "raw",
    "markdown": "markdown",
}

OXYLABS_EXTRACT_DEFAULT_FORMAT: ExtractFormat = "html"
"""Without the ``markdown`` flag Oxylabs returns the raw HTML it fetched."""

# --- Bright Data ------------------------------------------------------------
# Extract only: the Web Unlocker fetches a URL through Bright Data's network.
# Mapped from documentation -- no account was available to verify it live. See
# tests/providers/test_brightdata.py.

BRIGHTDATA_BASE_URL = "https://api.brightdata.com"
BRIGHTDATA_EXTRACT_PATH = "/request"
BRIGHTDATA_API_KEY_PREFIX = "Bearer "

BRIGHTDATA_RESPONSE_FORMAT = "json"
"""Always ask for the JSON envelope, never ``format="raw"``.

``raw`` returns the fetched page as the HTTP body itself -- no status code, no
headers, and not JSON, so decoding it would fail. The envelope carries the same
body under ``body`` plus the target's status and headers, which is strictly more
to normalize from. Bright Data's own reference shows the envelope beside a
``raw`` request, which reads as though ``raw`` returned it too; it does not.
"""

BRIGHTDATA_EXTRACT_FORMATS: dict[ExtractFormat, dict[str, Any]] = {
    # `data_format` post-processes what the unlocker fetched; absent, the
    # envelope's `body` holds the page's own HTML.
    "html": {},
    "markdown": {"data_format": "markdown"},
}

BRIGHTDATA_EXTRACT_DEFAULT_FORMAT: ExtractFormat = "html"

# --- Firecrawl --------------------------------------------------------------
# Extract only. Mapped from documentation -- no account was available to verify
# it live. See tests/providers/test_firecrawl.py.

FIRECRAWL_BASE_URL = "https://api.firecrawl.dev"
FIRECRAWL_EXTRACT_PATH = "/v2/scrape"
FIRECRAWL_API_KEY_PREFIX = "Bearer "

FIRECRAWL_EXTRACT_FORMATS: dict[ExtractFormat, str] = {
    # Normalized format -> the `formats` entry to ask for, which is also the key
    # under `data` the body lands in.
    "markdown": "markdown",
    "html": "html",
}

FIRECRAWL_EXTRACT_DEFAULT_FORMAT: ExtractFormat = "markdown"


# --- Jina Reader, the keyless route -----------------------------------------
# A key only raises the rate limit: 20 requests a minute without one, 500 with.
# Verified live, keyless.

JINA_BASE_URL = "https://r.jina.ai"
JINA_EXTRACT_PATH = "/"
JINA_API_KEY_PREFIX = "Bearer "
JINA_ACCEPT = "application/json"
"""Without it the reply is the page itself rather than a JSON envelope.

``Accept`` chooses the envelope and ``X-Return-Format`` chooses what is inside
it; they are independent, and asking only for a format returns bare text.
"""

JINA_RETURN_FORMAT_HEADER = "X-Return-Format"

JINA_EXTRACT_FORMATS: dict[ExtractFormat, str] = {
    # Normalized format -> the X-Return-Format value, which is also the key the
    # body lands under inside `data` -- except for markdown, which arrives as
    # `content`. Verified live: asking for html returns `data.html` and omits
    # `data.content` entirely, so the key has to follow the format.
    "markdown": "markdown",
    "html": "html",
    "text": "text",
}

JINA_BODY_FIELDS: dict[ExtractFormat, str] = {
    "markdown": "content",
    "html": "html",
    "text": "text",
}

JINA_EXTRACT_DEFAULT_FORMAT: ExtractFormat = "markdown"
"""Verified live: with no ``X-Return-Format`` the body arrives as ``data.content``."""

# Reader may answer from its own cache rather than fetching, and says so in an
# unmapped `data.warning` -- verified live: "This is a cached snapshot of the
# original page, consider retry with caching opt-out." That reaches the caller
# through ExtractedDocument.extra, which is where SECURITY.md points for it.
# Not mapped onto a normalized field: no other backend reports anything
# comparable, so there is nothing to normalize it against yet.
