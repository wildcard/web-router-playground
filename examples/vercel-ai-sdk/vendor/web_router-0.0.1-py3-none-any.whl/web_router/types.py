"""Provider-agnostic request and response models.

Every provider maps its own payload onto these types, so swapping Nimble for
Tavily or You.com does not change the shape of what callers get back. Anything a
provider returns that has no home here is preserved verbatim under
``SearchResult.extra`` / ``SearchResponse.raw`` for a search, and under
``ExtractedDocument.extra`` / ``ExtractResponse.raw`` for an extract.
"""

from __future__ import annotations

from enum import Enum
from typing import Annotated, Any, ClassVar, Literal

from pydantic import BaseModel, ConfigDict, Field

SearchDepth = Literal["lite", "fast", "deep"]
"""How much page content to retrieve per result.

- ``lite``: title, URL and description only — cheapest, best at high volume.
- ``fast``: a truncated page body, enough for most agent reasoning.
- ``deep``: full page content; slowest and most expensive.

Providers express this differently; each one maps these three levels onto its
own vocabulary.
"""


ExtractFormat = Literal["markdown", "html", "text"]
"""Which representation of a page to return.

- ``markdown``: the page as markdown -- structure kept, markup dropped.
- ``html``: the page's HTML, as the backend fetched it.
- ``text``: the visible text, with no markup at all.

Backends do not all offer all three: one that cannot produce the format you
asked for raises :class:`~web_router.exceptions.UnsupportedFormatError` rather
than returning a different one under the same name. See the format table in
README.md.
"""


class Provider(str, Enum):
    """The providers built into web-router.

    Every argument that names a provider also accepts a plain string; this
    exists so the built-in names are discoverable from an editor rather than
    remembered. Backends added with :func:`web_router.register_provider` are
    named by string, which is why the string form is never going away.

    Not every name serves every method: ``oxylabs``, ``brightdata``,
    ``firecrawl`` and ``jina`` extract but do not search, and most of the search
    backends do not extract. :func:`web_router.available_providers` and
    :func:`web_router.available_extract_providers` list each method's own set.
    """

    NIMBLE = "nimble"
    TAVILY = "tavily"
    YOU = "you"
    BRAVE = "brave"
    EXA = "exa"
    PARALLEL = "parallel"
    PERPLEXITY = "perplexity"
    YOU_MCP = "you-mcp"
    OXYLABS = "oxylabs"
    BRIGHTDATA = "brightdata"
    FIRECRAWL = "firecrawl"
    JINA = "jina"
    AUTO = "auto"

    # A str-mixin enum otherwise renders as "Provider.NIMBLE" in f-strings and
    # str(), which would reach users through error messages and `raw` payloads.
    __str__ = str.__str__


def provider_name(provider: str | Provider) -> str:
    """Normalize a provider argument to the plain lowercase name used for lookup."""
    return str(provider).lower()


class NormalizedRequest(BaseModel):
    """What every normalized request has in common.

    Each method has its own request model -- :class:`SearchRequest`,
    :class:`ExtractRequest` -- and they share only this: a set of optional
    parameters a provider may or may not map, and an untranslated passthrough.
    :meth:`SearchProvider.validate <web_router.SearchProvider.validate>` reads
    :meth:`specified_parameters` to reject a request carrying options the chosen
    backend does not map.
    """

    model_config = ConfigDict(extra="forbid")

    always_sent: ClassVar[frozenset[str]]
    """Fields the provider handles itself, so never an option it declares support for."""

    provider_options: dict[str, Any] = Field(
        default_factory=dict,
        description="Passed straight through to the underlying provider call, untranslated.",
    )

    @classmethod
    def normalized_parameters(cls) -> frozenset[str]:
        """Every optional parameter a provider may declare support for.

        Derived from the model rather than listed by hand, so adding a field is
        enough to make it part of the shared surface.
        """
        return frozenset(cls.model_fields) - cls.always_sent

    def specified_parameters(self) -> set[str]:
        """Names of the optional parameters this request actually sets."""
        return {name for name in self.normalized_parameters() if getattr(self, name) is not None}


class SearchRequest(NormalizedRequest):
    """A normalized search request.

    Only :attr:`query` is required. Fields left as ``None`` are omitted from the
    provider call so each backend applies its own default rather than ours.
    """

    always_sent: ClassVar[frozenset[str]] = frozenset({"query", "provider_options"})

    query: Annotated[str, Field(min_length=1, description="The search query.")]
    max_results: Annotated[int | None, Field(default=None, ge=1, description="Upper bound on results returned.")] = None
    search_depth: SearchDepth | None = Field(default=None, description="How much page content to retrieve.")
    include_domains: list[str] | None = Field(default=None, description="Restrict results to these domains.")
    exclude_domains: list[str] | None = Field(default=None, description="Drop results from these domains.")
    country: str | None = Field(default=None, description="Country code for geo-targeting, e.g. 'US'.")
    locale: str | None = Field(default=None, description="Language code, e.g. 'en'.")


ALWAYS_SENT = SearchRequest.always_sent
"""Fields every search provider handles itself: the query, and the untranslated passthrough."""

NORMALIZED_PARAMETERS: frozenset[str] = SearchRequest.normalized_parameters()
"""Every optional parameter a search provider may declare support for."""


class ExtractRequest(NormalizedRequest):
    """A normalized extract request.

    Only :attr:`urls` is required. :attr:`format` left as ``None`` means the
    backend returns whatever it returns by default, which
    :attr:`ExtractedDocument.format` then names.
    """

    always_sent: ClassVar[frozenset[str]] = frozenset({"urls", "provider_options"})

    urls: Annotated[
        list[Annotated[str, Field(min_length=1)]],
        Field(min_length=1, description="The URLs to fetch, in the order the documents come back."),
    ]
    format: ExtractFormat | None = Field(default=None, description="Which representation of each page to return.")


EXTRACT_ALWAYS_SENT = ExtractRequest.always_sent
"""Fields every extract provider handles itself: the URLs, and the untranslated passthrough."""

EXTRACT_PARAMETERS: frozenset[str] = ExtractRequest.normalized_parameters()
"""Every optional parameter an extract provider may declare support for."""


class SearchResult(BaseModel):
    """A single result, normalized across providers."""

    # Unknown keys are a provider bug: anything unmapped belongs in `extra`.
    model_config = ConfigDict(extra="forbid")

    url: str
    title: str = ""
    description: str = Field(
        default="",
        description=(
            "A snippet-length summary: the provider's own when it gives one, otherwise "
            "the head of the page body so the field means the same thing everywhere."
        ),
    )
    content: str = Field(
        default="",
        description=(
            "The fullest text available for this result: the page body when the provider "
            "returned one, otherwise the description. Empty only when there is no text at all."
        ),
    )
    score: float | None = Field(default=None, description="Provider relevance score, when one is given.")
    published_date: str | None = None
    extra: dict[str, Any] = Field(
        default_factory=dict,
        description="Provider-specific fields with no normalized equivalent.",
    )


class SearchResponse(BaseModel):
    """The result of one search, tagged with the provider that served it."""

    # Unknown keys are a provider bug: the untouched payload belongs in `raw`.
    model_config = ConfigDict(extra="forbid")

    provider: str
    query: str
    results: list[SearchResult] = Field(default_factory=list)
    answer: str | None = Field(default=None, description="Synthesized answer, when the provider returned one.")
    request_id: str | None = None
    raw: dict[str, Any] | None = Field(default=None, description="The provider's untouched response payload.")

    def __len__(self) -> int:
        return len(self.results)

    @property
    def urls(self) -> list[str]:
        """Every result URL, in rank order."""
        return [result.url for result in self.results]


class ExtractedDocument(BaseModel):
    """One fetched page, normalized across providers."""

    # Unknown keys are a provider bug: anything unmapped belongs in `extra`.
    model_config = ConfigDict(extra="forbid")

    url: str
    title: str = Field(default="", description="The page title, when the provider returned one.")
    content: str = Field(default="", description="The page body, in the representation :attr:`format` names.")
    format: ExtractFormat | None = Field(
        default=None,
        description=(
            "Which representation :attr:`content` holds -- the one asked for, or the backend's own "
            "default when none was. Never a guess: a provider that cannot return the requested "
            "format raises instead."
        ),
    )
    status_code: int | None = Field(default=None, description="The fetched page's HTTP status, when reported.")
    published_date: str | None = None
    extra: dict[str, Any] = Field(
        default_factory=dict,
        description="Provider-specific fields with no normalized equivalent.",
    )


class ExtractFailure(BaseModel):
    """A URL the provider could not fetch, and why."""

    model_config = ConfigDict(extra="forbid")

    url: str
    error: str


class ExtractResponse(BaseModel):
    """The result of one extract call, tagged with the provider that served it.

    Extracting several URLs can partly succeed: what came back is in
    :attr:`documents`, and every URL that did not is in :attr:`failures` with
    the reason. A call where *nothing* came back raises instead, so a failure
    is never something you have to go looking for.
    """

    # Unknown keys are a provider bug: the untouched payload belongs in `raw`.
    model_config = ConfigDict(extra="forbid")

    provider: str
    documents: list[ExtractedDocument] = Field(default_factory=list)
    failures: list[ExtractFailure] = Field(default_factory=list)
    request_id: str | None = Field(
        default=None,
        description=(
            "The provider's id for the request. Backends that take one URL per call issue one id "
            "per document; the first is reported here and all of them are in :attr:`raw`."
        ),
    )
    raw: list[dict[str, Any]] | None = Field(
        default=None,
        description=(
            "The provider's untouched response payloads, one per API call -- a single entry for a "
            "backend that takes every URL at once, one per URL for a backend that does not."
        ),
    )

    def __len__(self) -> int:
        return len(self.documents)

    @property
    def urls(self) -> list[str]:
        """Every document URL, in the order they were asked for."""
        return [document.url for document in self.documents]
