"""Provider registry, one table per method.

Providers are looked up by name and imported lazily, so installing web-router
without a provider's optional dependency stays valid until that provider is
actually requested.

There is a table per method rather than per vendor, because a name does not
imply a capability: ``brave`` searches and cannot extract, ``oxylabs`` extracts
and cannot search, and ``nimble`` does both through two different classes.
Asking the wrong table for a name reports it as unknown and lists the ones that
method does serve, which is the honest answer.
"""

from __future__ import annotations

import importlib
import os
from typing import TYPE_CHECKING, Any, TypeVar

from web_router.constants import (
    AUTO_EXTRA,
    ENV_BY_PROVIDER,
    EXTRA_EXTRACT,
    EXTRA_SEARCH,
    EXTRACT_ENV_BY_PROVIDER,
    PROVIDER_AUTO,
    PROVIDER_BRAVE,
    PROVIDER_BRIGHTDATA,
    PROVIDER_EXA,
    PROVIDER_FIRECRAWL,
    PROVIDER_JINA,
    PROVIDER_NIMBLE,
    PROVIDER_OXYLABS,
    PROVIDER_PARALLEL,
    PROVIDER_PERPLEXITY,
    PROVIDER_TAVILY,
    PROVIDER_YOU,
    PROVIDER_YOU_MCP,
)
from web_router.exceptions import ProviderNotFoundError, ProviderNotInstalledError
from web_router.types import Provider, provider_name

if TYPE_CHECKING:
    from web_router.providers.base import ExtractProvider, SearchProvider, _BaseProvider

_ProviderT = TypeVar("_ProviderT", bound="_BaseProvider")

# name -> (module path, class name, pip extra that supplies its SDK)
#
# Extras are per method, so every backend in a table points at the same one.
# The column stays because it is what ProviderNotInstalledError quotes back.
_BUILTIN_PROVIDERS: dict[str, tuple[str, str, str]] = {
    PROVIDER_NIMBLE: ("web_router.providers.nimble", "NimbleProvider", EXTRA_SEARCH),
    PROVIDER_TAVILY: ("web_router.providers.tavily", "TavilyProvider", EXTRA_SEARCH),
    PROVIDER_YOU: ("web_router.providers.you", "YouProvider", EXTRA_SEARCH),
    PROVIDER_BRAVE: ("web_router.providers.brave", "BraveProvider", EXTRA_SEARCH),
    PROVIDER_EXA: ("web_router.providers.exa", "ExaProvider", EXTRA_SEARCH),
    PROVIDER_PARALLEL: ("web_router.providers.parallel", "ParallelProvider", EXTRA_SEARCH),
    PROVIDER_PERPLEXITY: ("web_router.providers.perplexity", "PerplexityProvider", EXTRA_SEARCH),
    PROVIDER_YOU_MCP: ("web_router.providers.you_mcp", "YouMcpProvider", EXTRA_SEARCH),
    PROVIDER_AUTO: ("web_router.providers.auto", "AutoProvider", AUTO_EXTRA),
}

_BUILTIN_EXTRACT_PROVIDERS: dict[str, tuple[str, str, str]] = {
    PROVIDER_NIMBLE: ("web_router.providers.nimble", "NimbleExtractProvider", EXTRA_EXTRACT),
    PROVIDER_TAVILY: ("web_router.providers.tavily", "TavilyExtractProvider", EXTRA_EXTRACT),
    PROVIDER_EXA: ("web_router.providers.exa", "ExaExtractProvider", EXTRA_EXTRACT),
    PROVIDER_FIRECRAWL: ("web_router.providers.firecrawl", "FirecrawlExtractProvider", EXTRA_EXTRACT),
    PROVIDER_OXYLABS: ("web_router.providers.oxylabs", "OxylabsExtractProvider", EXTRA_EXTRACT),
    PROVIDER_BRIGHTDATA: ("web_router.providers.brightdata", "BrightDataExtractProvider", EXTRA_EXTRACT),
    PROVIDER_JINA: ("web_router.providers.jina", "JinaExtractProvider", EXTRA_EXTRACT),
    PROVIDER_AUTO: ("web_router.providers.auto", "AutoExtractProvider", AUTO_EXTRA),
}

_CUSTOM_PROVIDERS: dict[str, type[SearchProvider]] = {}
_CUSTOM_EXTRACT_PROVIDERS: dict[str, type[ExtractProvider]] = {}


def register_provider(name: str | Provider, provider_cls: type[SearchProvider]) -> None:
    """Register a search provider class under ``name``, overriding any builtin of that name."""
    _CUSTOM_PROVIDERS[provider_name(name)] = provider_cls


def unregister_provider(name: str | Provider) -> None:
    """Remove a previously registered custom search provider. A no-op if it was never registered."""
    _CUSTOM_PROVIDERS.pop(provider_name(name), None)


def register_extract_provider(name: str | Provider, provider_cls: type[ExtractProvider]) -> None:
    """Register an extract provider class under ``name``, overriding any builtin of that name."""
    _CUSTOM_EXTRACT_PROVIDERS[provider_name(name)] = provider_cls


def unregister_extract_provider(name: str | Provider) -> None:
    """Remove a previously registered custom extract provider. A no-op if it was never registered."""
    _CUSTOM_EXTRACT_PROVIDERS.pop(provider_name(name), None)


def available_providers() -> list[str]:
    """Every search provider name the router knows, installed or not."""
    return sorted(set(_BUILTIN_PROVIDERS) | set(_CUSTOM_PROVIDERS))


def available_extract_providers() -> list[str]:
    """Every extract provider name the router knows, installed or not."""
    return sorted(set(_BUILTIN_EXTRACT_PROVIDERS) | set(_CUSTOM_EXTRACT_PROVIDERS))


def configured_providers() -> list[str]:
    """Every builtin search provider you currently have a credential for, plus the keyless ones.

    Reports what the environment makes usable, which
    :func:`available_providers` deliberately does not: that lists every name
    the router knows, key or no key.

    This reads environment variables only. A key passed as ``provider_config``
    is invisible here, and a key that is present may still be rejected by the
    service -- so treat this as "worth trying", not as a guarantee, and let the
    provider itself raise when a credential is actually missing or bad.
    """
    return sorted(name for name, env_var in ENV_BY_PROVIDER.items() if env_var is None or os.environ.get(env_var))


def configured_extract_providers() -> list[str]:
    """Every builtin extract provider you currently have credentials for, plus the keyless ones.

    The same caveats as :func:`configured_providers`. A backend needing more
    than one variable -- Oxylabs its username and password, Bright Data its
    token and zone -- is reported only when it has all of them.
    """
    return sorted(
        name
        for name, env_vars in EXTRACT_ENV_BY_PROVIDER.items()
        if all(os.environ.get(env_var) for env_var in env_vars)
    )


def _resolve(
    name: str | Provider,
    *,
    builtin: dict[str, tuple[str, str, str]],
    custom: dict[str, type[_ProviderT]],
    available: list[str],
) -> type[_ProviderT]:
    """Look a name up in one method's tables, importing its module on first use."""
    key = provider_name(name)

    if key in custom:
        return custom[key]

    if key not in builtin:
        raise ProviderNotFoundError(key, available)

    module_path, class_name, extra = builtin[key]
    try:
        module = importlib.import_module(module_path)
    except ImportError as exc:
        # Only the missing SDK means "not installed". An ImportError from inside
        # the provider module is a bug, and reporting it as a missing extra would
        # send the reader looking in entirely the wrong place.
        if exc.name and exc.name.startswith("web_router"):
            raise
        raise ProviderNotInstalledError(key, extra) from exc

    provider_cls: type[_ProviderT] = getattr(module, class_name)
    return provider_cls


def get_provider_class(name: str | Provider) -> type[SearchProvider]:
    """Resolve a search provider name to its class, importing the module on first use."""
    return _resolve(
        name,
        builtin=_BUILTIN_PROVIDERS,
        custom=_CUSTOM_PROVIDERS,
        available=available_providers(),
    )


def get_extract_provider_class(name: str | Provider) -> type[ExtractProvider]:
    """Resolve an extract provider name to its class, importing the module on first use."""
    return _resolve(
        name,
        builtin=_BUILTIN_EXTRACT_PROVIDERS,
        custom=_CUSTOM_EXTRACT_PROVIDERS,
        available=available_extract_providers(),
    )


def create_provider(name: str | Provider, **kwargs: Any) -> SearchProvider:
    """Instantiate a search provider by name, passing ``kwargs`` to its constructor."""
    return get_provider_class(name)(**kwargs)


def create_extract_provider(name: str | Provider, **kwargs: Any) -> ExtractProvider:
    """Instantiate an extract provider by name, passing ``kwargs`` to its constructor."""
    return get_extract_provider_class(name)(**kwargs)
